#!/usr/bin/env python3
import argparse, hashlib, json, os
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from pathlib import Path

PREFIX = 'workspace-snapshot_'

def sha256(path, chunk=1024*1024):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while True:
            b=f.read(chunk)
            if not b: break
            h.update(b)
    return h.hexdigest()

def scan(root: Path):
    files=[]
    for p in sorted(root.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(root).as_posix()
        if p.name.startswith(PREFIX) and p.suffix=='.json':
            continue
        try:
            st=p.stat()
            files.append({'path':rel,'size':st.st_size,'sha256':sha256(p)})
        except (OSError, PermissionError) as e:
            files.append({'path':rel,'error':type(e).__name__})
    return files

def snapshot(root: Path, out: Path|None, timezone_name: str):
    now=datetime.now(ZoneInfo(timezone_name))
    data={'generatedAt':now.isoformat(timespec='seconds'),'root':str(root.resolve()),'files':scan(root)}
    if out is None:
        out=root/f"{PREFIX}{now.strftime('%Y%m%d_%H%M%S')}.json"
    out.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(out)

def compare(root: Path, previous: Path):
    old=json.loads(previous.read_text(encoding='utf-8'))
    oldm={x['path']:x for x in old.get('files',[]) if 'path' in x}
    newm={x['path']:x for x in scan(root) if 'path' in x}
    added=sorted(set(newm)-set(oldm)); missing=sorted(set(oldm)-set(newm))
    common=set(oldm)&set(newm)
    changed=sorted(p for p in common if oldm[p].get('size')!=newm[p].get('size') or oldm[p].get('sha256')!=newm[p].get('sha256'))
    unchanged=len(common)-len(changed)
    print(json.dumps({'root':str(root.resolve()),'previous':str(previous),'added':added,'missing':missing,'changed':changed,'unchangedCount':unchanged},ensure_ascii=False,indent=2))

def main():
    ap=argparse.ArgumentParser(prog='workspace-snapshot')
    ap.add_argument('--root',default='.',help='workspace root (default: current directory)')
    ap.add_argument('--timezone',default=os.environ.get('WORKSPACE_SNAPSHOT_TZ','Asia/Tokyo'),help='IANA timezone for generatedAt/filename (default: Asia/Tokyo)')
    sub=ap.add_subparsers(dest='cmd')
    s=sub.add_parser('create'); s.add_argument('--output')
    c=sub.add_parser('compare'); c.add_argument('snapshot')
    a=ap.parse_args(); root=Path(a.root).expanduser().resolve()
    if a.cmd in (None,'create'):
        snapshot(root, Path(a.output).resolve() if getattr(a,'output',None) else None, a.timezone)
    elif a.cmd=='compare':
        compare(root,Path(a.snapshot).expanduser().resolve())
if __name__=='__main__': main()
