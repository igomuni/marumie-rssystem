# workspace-snapshot

Create and compare deterministic workspace inventory snapshots for handoff/recovery across agent sessions.

## Create
Run:

```bash
python3 .agents/skills/workspace-snapshot/scripts/snapshot.py --root <workspace-root> create
```

The output filename is `workspace-snapshot_YYYYMMDD_HHMMSS.json` in the workspace root. Each regular file records `path`, byte `size`, and `sha256`. Existing `workspace-snapshot_*.json` files are excluded so snapshots do not recursively change themselves.

## Compare
Run:

```bash
python3 .agents/skills/workspace-snapshot/scripts/snapshot.py --root <workspace-root> compare <previous-snapshot.json>
```

Report `added`, `missing`, `changed`, and `unchangedCount`.

## Usage
Use at useful handoff points, especially before ending long-running work. At resume, compare the previous snapshot when one is supplied or available. Do not infer missing files from conversational memory; compare against the actual workspace.
