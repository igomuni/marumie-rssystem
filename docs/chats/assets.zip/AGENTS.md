# Agent workspace instructions

## Workspace snapshots

For long-running or multi-session work, use the `workspace-snapshot` skill at `.agents/skills/workspace-snapshot/`. If the user says `workspace-snapshot`, run the skill directly and return the generated snapshot artifact.

- At a useful handoff/end point, create a workspace snapshot and return it as an artifact.
- At resume, if a prior snapshot is available, compare it with the current workspace before assuming prior intermediate files still exist.
- Treat the current filesystem as authoritative for file presence; use the snapshot to identify added, missing, or changed files.

## Intermediate artifacts

Store task-specific intermediate artifacts under:

`docs/tasks/<YYYYMMDD_task-name>/`

- Use the same relative directory structure as the GitHub repository whenever practical.
- Put generated intermediate reports, CSVs, HTML files, mocks, and investigation notes in `docs/tasks/` rather than scattering them in the workspace root.
- Keep source/raw inputs, reusable tooling, workspace snapshots, and final transport/archive artifacts outside `docs/tasks/` unless the task explicitly requires otherwise.
- When continuing an existing task, reuse its existing `docs/tasks/` directory rather than creating a duplicate task directory.
