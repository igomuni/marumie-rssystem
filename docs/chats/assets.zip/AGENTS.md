# Agent workspace instructions

## Workspace snapshots

For long-running or multi-session work, use the `workspace-snapshot` skill at `.agents/skills/workspace-snapshot/`.

- At a useful handoff/end point, create a workspace snapshot and return it as an artifact.
- At resume, if a prior snapshot is available, compare it with the current workspace before assuming prior intermediate files still exist.
- Treat the current filesystem as authoritative for file presence; use the snapshot to identify added, missing, or changed files.
