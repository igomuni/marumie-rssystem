#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from pipeline_v2.normalize_mof import normalize_mof
from pipeline_v2.normalize_rs import normalize_rs, discover_rs_years
from pipeline_v2.derive import derive_all
from pipeline_v2.validate import validate_all
from pipeline_v2.publish import publish_all
from pipeline_v2.validate_public import validate_public


def discover_mof_years(raw_root: Path) -> list[int]:
    root = raw_root / 'mof.go.jp' / 'archive'
    if not root.exists(): return []
    return sorted(int(p.name) for p in root.iterdir() if p.is_dir() and p.name.isdigit())


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description='Independent unified reference implementation for marumie-rssystem Pipeline V2')
    p.add_argument('--raw-root', type=Path, required=True, help='Directory containing mof.go.jp/ and rssystem.go.jp/')
    p.add_argument('--output-root', type=Path, required=True, help='Local normalized/derived/validation workspace')
    p.add_argument('--public-root', type=Path, required=True, help='Deployment artifact root; writes public/data/v2 only')
    p.add_argument('--fiscal-years', nargs='*', type=int, default=None, help='Default: discover from MOF raw archive')
    p.add_argument('--review-years', nargs='*', type=int, default=None, help='Default: discover from RS download-csv/sheets')
    p.add_argument('--skip-normalize', action='store_true')
    p.add_argument('--skip-derive', action='store_true')
    p.add_argument('--skip-validation', action='store_true')
    return p.parse_args()


def main() -> None:
    args = parse_args()
    fys = args.fiscal_years if args.fiscal_years is not None else discover_mof_years(args.raw_root)
    rys = args.review_years if args.review_years is not None else discover_rs_years(args.raw_root)
    args.output_root.mkdir(parents=True, exist_ok=True)
    args.public_root.mkdir(parents=True, exist_ok=True)
    print(f'fiscalYears={fys} reviewYears={rys}')
    if not args.skip_normalize:
        print('[1/5] normalize MOF')
        normalize_mof(args.raw_root, args.output_root, set(fys))
        print('[2/5] normalize RS')
        normalize_rs(args.raw_root, args.output_root, set(rys))
    if not args.skip_derive:
        print('[3/5] derive MOF / RS / links')
        derive_all(args.output_root, fys, rys)
    if not args.skip_validation:
        print('[4/5] validate normalized/derived')
        validate_all(args.raw_root, args.output_root, fys, rys)
    print('[5/5] publish public/data/v2')
    manifest = publish_all(args.output_root, args.public_root, fys, rys)
    report = validate_public(args.public_root)
    import json
    validation_path = args.output_root / 'validation' / 'public-report.json'
    validation_path.parent.mkdir(parents=True, exist_ok=True)
    validation_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"public bytes={manifest.get('totalPublicBytes')} validation={report['ok']} warnings={len(report['warnings'])}")
    if not report['ok']:
        raise SystemExit('public validation failed')


if __name__ == '__main__':
    main()
