# Design Notes — Unified Pipeline V2

## Why `public/budget-flow-v2` should be retired

Current `main` has two separate V2 paths:

1. TypeScript V2: raw → normalized → derived → validate.
2. `generate-budget-flow.py`: independent reference ZIP → `public/budget-flow-v2`.

The second path also reads V1 `public/data/mof-budget-*.json.gz` for comparison and has a screen-specific schema. It should become a compatibility adapter only during migration, then be removed after `/budget-flow` reads `public/data/v2`.

## Why section and item must both exist

The current TypeScript `BudgetEntity` is item-level because `itemName` participates in identity. The current Budget Flow adapter is section-level and places item rows under evidence. Neither representation is wrong; they serve different levels. The unified model treats:

```text
MOF section (項)
  └─ MOF item (目)
```

as two explicit levels. Public list/detail is section-oriented, while link evidence can still point to item IDs.

## Why links are `reviewYear × fiscalYear`

RS review year is a snapshot/cohort, not the same thing as the budget fiscal year. A link product therefore uses an explicit pair such as `review-2025-fy2024`; it must never be stored under a single ambiguous `year` key.

## Why 256 shards

One-file-per-PID would create ~5,800 static files per review year. Sixteen shards are too coarse when detail payloads grow. 256 deterministic shards keep the static file count manageable and give current full-data averages of tens of KiB per detail fetch.

## MOF stage gaps

The structured settlement CSV does not always expose the relation that explains the change between post-supplement budget and the settlement-side budget appropriation. For the Digital Agency information-system appropriation, the delta is `-509,690,849,950` yen, matching the RS neutral adjustment field and the known official transfer scale, while the row-level `transfer_adjustment` event itself is zero.

The publisher therefore emits:

```text
unresolvedPreSettlementDeltaYen
```

and a `stageGaps` detail record. This is evidence of an intervening change, not a semantic assertion that it is a transfer. An official transfer-relation parser can later resolve the gap.

## Vercel/static build boundary

`public/data/v2/**` should remain browser-static only. Do not copy it to `data/server/**` in `prebuild`. Current `next.config.ts` already excludes `public/data/**` from server function tracing, which is desirable for V2.

The repository `.gitignore` must explicitly allow nested V2 `.json.gz` files and the small V2 manifests because the existing exception only covers root-level `public/data/*.gz`.
