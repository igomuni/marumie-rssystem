# Pipeline V2 Unified Reference (MOF + RS + publish)

Independent reference implementation for `igomuni/marumie-rssystem` Pipeline V2.
It is intentionally separate from the repository's production TypeScript pipeline so the two implementations can be compared independently.

## Target architecture

```text
raw/download
  ├─ mof.go.jp
  └─ rssystem.go.jp
        ↓
normalized
  ├─ mof/fyYYYY
  └─ rs/review-YYYY
        ↓
derived
  ├─ mof/fyYYYY
  ├─ rs/review-YYYY
  └─ links/mof-rs-review-YYYY-fyYYYY
        ↓
validation
        ↓
publish
        ↓
public/data/v2
```

`normalized` and `derived` are local build artifacts. Only `public/data/v2` is intended for deployment.

## Important semantic rules

- MOF `fiscalYear` and RS `reviewYear` are different dimensions.
- MOF section (項) and sub-item (目) are separate identities.
- RS project IDs such as `4` and `000004` resolve to the same canonical project ID while raw IDs remain in normalized evidence.
- Blank and explicit zero are distinct in normalized data and in public budget summaries (omitted key = blank, `0` = explicit zero).
- RS `予備費等` is not automatically classified as reserve. It remains neutral until evidence supports a semantic classification.
- RS 5-2 is a general directed funding graph: cycles, fan-in/fan-out, multiple roots, disconnected components, duplicate evidence, and orphan blocks are all valid.
- MOF's gap from post-supplement budget to the settlement-side budget appropriation is published as `unresolvedPreSettlementDeltaYen` when non-zero. Do not call the gap a transfer without official relation evidence. PID:4 / the Digital Agency information-system appropriation is the key regression case.

## Public layout

```text
public/data/v2/
├─ manifest.json
├─ mof/
│  └─ fy2024/
│     ├─ manifest.json
│     ├─ index.json.gz
│     └─ sections/00.json.gz ... ff.json.gz
├─ rs/
│  └─ review-2025/
│     ├─ manifest.json
│     ├─ index.json.gz
│     ├─ core/00.json.gz ... ff.json.gz
│     ├─ context/00.json.gz ... ff.json.gz
│     └─ spending/00.json.gz ... ff.json.gz
└─ links/
   └─ review-2025-fy2024/
      ├─ manifest.json
      └─ links.json.gz
```

The 256-way shard layout avoids thousands of tiny deployed files while keeping a selected entity fetch small. List/filter fields live in the index, so the UI never needs to load every detail shard merely to sort by amount.

### RS profiles

- `core`: project, project-level budget summaries, funding graph, MOF link references.
- `context`: detailed budget items, policy/law, subsidy rules, related projects, logic model, evaluations, notes.
- `spending`: recipients, contracts, expense/use rows, multi-year contracts, indirect expenses.

The UI can lazy-load context/spending tabs. All three profiles may still be deployed as static files.

## Run

```bash
python run_pipeline.py \
  --raw-root /path/to/raw-root \
  --output-root /path/to/work \
  --public-root /path/to/public
```

`--public-root` means the directory that will contain `data/v2`, i.e. the repository's actual `public/` directory.

Years are discovered from the raw source tree by default. They can be restricted explicitly with `--fiscal-years` and `--review-years`.

## Current full-data reference measurement (2026-09-20)

Using the supplied MOF 2024/2025 raw archive, RS 2025 15 CSV groups, and available 2026 sheets:

- MOF FY2024: 1,311 sections.
- MOF FY2025: 1,100 sections.
- RS review 2025: 5,798 projects.
- RS review 2026 sheets-only: 2,579 projects.
- MOF↔RS review2025/FY2024: 4,914 link groups, 4,537 linked projects.
- MOF↔RS review2025/FY2025: 5,086 link groups, 4,851 linked projects.
- full modular `public/data/v2`: about 45.4 MiB / 1,546 files.
- maximum single static file: ~696 KiB (RS index); no file exceeds 1 MiB.

Normalized/derived output is much larger (~GB scale) but is not a deployment artifact.
