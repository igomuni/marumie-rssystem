from __future__ import annotations

import gzip
import hashlib
import json
import shutil
import tempfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator

from .common import SCHEMA_VERSION, read_jsonl

PUBLISH_SCHEMA_VERSION = 1
SHARD_COUNT = 256


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _write_json(path: Path, value: Any) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = _json_bytes(value)
    path.write_bytes(data)
    return len(data)


def _write_gzip_json(path: Path, value: Any) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = _json_bytes(value)
    # mtime=0 makes the artifact byte-for-byte deterministic for identical input.
    compressed = gzip.compress(data, compresslevel=9, mtime=0)
    path.write_bytes(compressed)
    return len(compressed)


def _stable_hex(*parts: Any) -> str:
    payload = json.dumps(parts, ensure_ascii=False, separators=(",", ":"), sort_keys=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:20]


def _rs_shard(project_id: str) -> str:
    return hashlib.sha256(f"rs-project:{project_id}".encode("utf-8")).hexdigest()[:2]


def _mof_section_tuple(row: dict[str, Any]) -> tuple[str, ...]:
    return (
        row.get("accountType", ""),
        row.get("ministry", ""),
        row.get("organization", ""),
        row.get("specialAccount", ""),
        row.get("subAccount", ""),
        row.get("agency", ""),
        row.get("sectionCode", ""),
        row.get("sectionName", ""),
    )


def _mof_section_id(fiscal_year: int, row: dict[str, Any]) -> str:
    return _stable_hex("mof-section", fiscal_year, *_mof_section_tuple(row))


def _mof_item_id(fiscal_year: int, row: dict[str, Any]) -> str:
    return _stable_hex("mof-item", fiscal_year, row.get("itemNaturalKey") or "", row.get("subItemName") or "")


def _meaningful(value: Any) -> bool:
    if value is None or value == "" or value == [] or value == {}:
        return False
    return True


def _pick(row: dict[str, Any], keys: Iterable[str], *, keep_zero: bool = True) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key in keys:
        value = row.get(key)
        if value is None or value == "" or value == [] or value == {}:
            continue
        if not keep_zero and value == 0:
            continue
        out[key] = value
    return out


def _compact_source(source: dict[str, Any] | None) -> dict[str, Any] | None:
    if not source:
        return None
    return _pick(source, ("domain", "dataset", "year", "path", "zipEntry", "rowNumber", "sourceUrl"))


def _compact_rs_project(row: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "projectId", "projectName", "ministry", "bureau", "department", "division", "office", "team", "unit",
        "accountClass", "majorExpense", "purpose", "currentIssues", "overview", "overviewUrl", "startYear", "endYear",
        "noPlannedEnd", "projectCategory", "legacyProjectNumber", "officialProjectUrl", "implementationMethods", "remarks",
    )
    return _pick(row, keys)


def _compact_rs_summary(row: dict[str, Any]) -> dict[str, Any]:
    # Omitted key means blank/missing. Explicit zero is retained as 0.
    amounts = {k: v for k, v in (row.get("amounts") or {}).items() if v is not None}
    out = {
        "fiscalYear": row.get("fiscalYear"),
        "scopeLevel": row.get("scopeLevel"),
        "amounts": amounts,
    }
    out.update(_pick(row, ("account", "accountClass", "accountType", "subAccount", "changeReason", "note", "specialNotes", "executionRateRaw")))
    return {k: v for k, v in out.items() if v is not None and v != "" and v != {}}


def _compact_rs_budget_item(row: dict[str, Any]) -> dict[str, Any]:
    return _pick(row, (
        "recordId", "fiscalYear", "requestFiscalYear", "budgetType", "accountType", "accountClass", "account", "subAccount",
        "ministry", "organizationOrAccount", "sectionName", "subItemName", "budgetAmountYen", "nextYearRequestYen", "note", "supplementalInfo",
    ))


def _compact_graph(graph: dict[str, Any]) -> dict[str, Any]:
    nodes: list[dict[str, Any]] = []
    for n in graph.get("nodes", []):
        out = _pick(n, ("nodeId", "nodeType", "blockId", "name", "nameVariants", "roles", "totalAmountValuesYen", "recipientCountValues", "synthetic", "syntheticReason"))
        nodes.append(out)
    edges: list[dict[str, Any]] = []
    for e in graph.get("semanticEdges", []):
        out = _pick(e, (
            "edgeId", "sourceNodeId", "targetNodeId", "evidenceCount", "noteVariants", "fromResponsibleOrganizationValues",
            "amountYen", "amountStatus", "sourceNameVariants", "targetNameVariants",
        ))
        edges.append(out)
    metrics = _pick(graph.get("metrics") or {}, (
        "blockCount", "nodeCount", "semanticEdgeCount", "relationEvidenceCount", "hasCycle", "cyclicComponents",
        "weakComponentCount", "weakComponentSizes", "maxOutDegree", "maxInDegree", "orphanBlockIds", "externalRootBlockIds",
        "duplicateRelationPairCount", "duplicateRelationEvidenceExtraCount", "indirectExpenseCount", "sameNameMultipleBlocks",
        "hasResponsibleOrganizationRoot", "rootNodeIds", "unresolvedRelationEvidenceCount",
    ))
    return {"nodes": nodes, "edges": edges, "metrics": metrics}


def _strip_rs_common(row: dict[str, Any], extra_drop: set[str] | None = None) -> dict[str, Any]:
    drop = {
        "schemaVersion", "recordType", "sourceSystem", "sourceYear", "reviewYear", "projectId", "projectIdRaw", "projectName",
        "ministry", "policyMinistry", "ministryOrderRaw", "bureau", "department", "division", "office", "team", "unit",
        "sheetType", "extraFields", "source", "sources", "sourceRowId", "evidenceRowIds",
    }
    if extra_drop:
        drop |= extra_drop
    return {k: v for k, v in row.items() if k not in drop and _meaningful(v)}


def _compact_policy(row: dict[str, Any]) -> dict[str, Any] | None:
    out = _strip_rs_common(row, {"recordId"})
    # Empty placeholder rows are not useful in public products.
    if not any(out.get(k) for k in ("policy", "measure", "lawName", "planName", "policyMeasureUrl", "planUrl")):
        return None
    return out


def _compact_subsidy(row: dict[str, Any]) -> dict[str, Any] | None:
    if row.get("hasRule") is False and not any(row.get(k) for k in ("target", "rateRaw", "upperLimitRaw", "url")):
        return None
    return _strip_rs_common(row, {"recordId"})


def _compact_project_relation(row: dict[str, Any]) -> dict[str, Any] | None:
    if row.get("hasRelation") is False and not row.get("relatedProjectId"):
        return None
    return _strip_rs_common(row, {"recordId"})


def _compact_logic_node(row: dict[str, Any]) -> dict[str, Any]:
    return _strip_rs_common(row)


def _compact_logic_observation(row: dict[str, Any]) -> dict[str, Any]:
    return _strip_rs_common(row, {"observationId"})


def _compact_logic_relation(row: dict[str, Any]) -> dict[str, Any] | None:
    if row.get("hasRelation") is False and not row.get("targetLogicNodeId"):
        return None
    return _strip_rs_common(row)


def _compact_evaluation(row: dict[str, Any]) -> dict[str, Any]:
    return _strip_rs_common(row, {"recordId"})


def _compact_note(row: dict[str, Any]) -> dict[str, Any] | None:
    note = row.get("note")
    if not note:
        return None
    return {"note": note}


def _compact_recipient(row: dict[str, Any]) -> dict[str, Any]:
    return _pick(row, ("recipientId", "blockId", "recipientName", "corporateNumber", "corporateType", "location", "otherRecipient", "totalAmountValuesYen"))


def _compact_contract(row: dict[str, Any]) -> dict[str, Any]:
    return _pick(row, (
        "contractId", "blockId", "recipientId", "recipientNameRaw", "corporateNumberRaw", "amountYen", "summary", "method", "methodDetail",
        "bidderCount", "winningRate", "singleBidReason", "otherContract",
    ))


def _compact_expense_use(row: dict[str, Any]) -> dict[str, Any]:
    return _pick(row, ("expenseUseId", "blockId", "recipientName", "corporateNumber", "expenseItem", "use", "amountYen", "contractSummary"))


def _compact_multi_contract(row: dict[str, Any]) -> dict[str, Any] | None:
    if not row.get("hasContract"):
        return None
    return _pick(row, (
        "contractId", "blockId", "recipientName", "corporateNumber", "corporateType", "location", "amountYen", "summary", "method", "methodDetail",
        "bidderCount", "winningRate", "singleBidReason",
    ))


def _compact_indirect(row: dict[str, Any]) -> dict[str, Any]:
    return _pick(row, ("expenseId", "categoryRaw", "item", "amountYen"))


def _iter_jsonl(path: Path) -> Iterator[dict[str, Any]]:
    yield from read_jsonl(path)


def _shard_rows_to_temp(
    path: Path,
    temp_root: Path,
    profile: str,
    category: str,
    compact: Callable[[dict[str, Any]], dict[str, Any] | None],
) -> int:
    if not path.exists():
        return 0
    handles: dict[str, Any] = {}
    count = 0
    try:
        for row in _iter_jsonl(path):
            pid = str(row.get("projectId") or "")
            if not pid:
                continue
            item = compact(row)
            if item is None:
                continue
            shard = _rs_shard(pid)
            handle = handles.get(shard)
            if handle is None:
                p = temp_root / profile / f"{shard}.jsonl"
                p.parent.mkdir(parents=True, exist_ok=True)
                handle = p.open("a", encoding="utf-8")
                handles[shard] = handle
            handle.write(json.dumps({"projectId": pid, "category": category, "value": item}, ensure_ascii=False, separators=(",", ":")) + "\n")
            count += 1
    finally:
        for h in handles.values():
            h.close()
    return count


def _shard_graphs_to_temp(path: Path, temp_root: Path) -> int:
    if not path.exists():
        return 0
    handles: dict[str, Any] = {}
    count = 0
    try:
        for graph in _iter_jsonl(path):
            pid = str(graph.get("projectId") or "")
            if not pid:
                continue
            shard = _rs_shard(pid)
            handle = handles.get(shard)
            if handle is None:
                p = temp_root / "core" / f"{shard}.jsonl"
                p.parent.mkdir(parents=True, exist_ok=True)
                handle = p.open("a", encoding="utf-8")
                handles[shard] = handle
            handle.write(json.dumps({"projectId": pid, "category": "fundingGraph", "value": _compact_graph(graph)}, ensure_ascii=False, separators=(",", ":")) + "\n")
            count += 1
    finally:
        for h in handles.values():
            h.close()
    return count


def _load_project_links_for_rs(work_root: Path, review_year: int) -> tuple[dict[str, list[dict[str, Any]]], list[dict[str, Any]]]:
    by_project: dict[str, list[dict[str, Any]]] = defaultdict(list)
    products: list[dict[str, Any]] = []
    link_dir = work_root / "derived" / "links"
    for path in sorted(link_dir.glob(f"mof-rs-review-{review_year}-fy*.jsonl")):
        try:
            fiscal_year = int(path.stem.rsplit("fy", 1)[1])
        except Exception:
            continue
        count = 0
        projects: set[str] = set()
        for link in read_jsonl(path):
            compact = {
                "linkId": link.get("linkId"),
                "fiscalYear": fiscal_year,
                "phase": link.get("phase"),
                "revision": link.get("revision"),
                "matchMethod": link.get("matchMethod"),
                "mofAmountYen": link.get("mofAmountYen"),
                "rsAmountYen": link.get("rsAmountYen"),
                "differenceYen": link.get("differenceYen"),
            }
            for pid in link.get("projectIds") or []:
                pid = str(pid)
                by_project[pid].append(compact)
                projects.add(pid)
            count += 1
        products.append({"reviewYear": review_year, "fiscalYear": fiscal_year, "linkGroupCount": count, "projectCount": len(projects)})
    return by_project, products


def publish_rs_year(work_root: Path, public_root: Path, review_year: int) -> dict[str, Any] | None:
    nroot = work_root / "normalized" / "rs" / f"review-{review_year}"
    if not nroot.exists():
        return None
    out = public_root / "data" / "v2" / "rs" / f"review-{review_year}"
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)

    droot = work_root / "derived" / "rs" / f"review-{review_year}"
    project_links, link_products = _load_project_links_for_rs(work_root, review_year)

    projects: dict[str, dict[str, Any]] = {}
    for row in read_jsonl(nroot / "projects.jsonl"):
        pid = str(row.get("projectId") or "")
        if pid:
            projects[pid] = _compact_rs_project(row)

    graph_metrics: dict[str, dict[str, Any]] = {}
    graph_path = droot / "funding-graphs.jsonl"
    if graph_path.exists():
        for graph in read_jsonl(graph_path):
            pid = str(graph.get("projectId") or "")
            if pid:
                graph_metrics[pid] = _compact_graph(graph).get("metrics", {})

    # Project-total budget amounts make the index useful without loading all detail shards.
    index_budget: dict[str, dict[str, Any]] = defaultdict(dict)
    for row in read_jsonl(nroot / "budget-summaries.jsonl"):
        if row.get("scopeLevel") != "project_total":
            continue
        pid = str(row.get("projectId") or "")
        fy = row.get("fiscalYear")
        if not pid or fy is None:
            continue
        amounts = row.get("amounts") or {}
        index_budget[pid][str(fy)] = {k: v for k, v in amounts.items() if v is not None and k in {
            "当初予算（合計）", "補正予算（合計）", "計（歳出予算現額合計）", "執行額（合計）", "翌年度要求額（合計）", "翌年度への繰越し(合計）"
        }}

    temp_root = Path(tempfile.mkdtemp(prefix=f"pv2-publish-rs-{review_year}-"))
    try:
        # Seed project core objects.
        handles: dict[str, Any] = {}
        try:
            for pid, project in projects.items():
                shard = _rs_shard(pid)
                h = handles.get(shard)
                if h is None:
                    p = temp_root / "core" / f"{shard}.jsonl"
                    p.parent.mkdir(parents=True, exist_ok=True)
                    h = p.open("a", encoding="utf-8")
                    handles[shard] = h
                h.write(json.dumps({"projectId": pid, "category": "project", "value": project}, ensure_ascii=False, separators=(",", ":")) + "\n")
                for link in project_links.get(pid, []):
                    h.write(json.dumps({"projectId": pid, "category": "mofLinks", "value": link}, ensure_ascii=False, separators=(",", ":")) + "\n")
        finally:
            for h in handles.values(): h.close()

        counts: dict[str, int] = {}
        counts["budgetSummaries"] = _shard_rows_to_temp(nroot / "budget-summaries.jsonl", temp_root, "core", "budgetSummaries", _compact_rs_summary)
        counts["budgetItems"] = _shard_rows_to_temp(nroot / "budget-items.jsonl", temp_root, "context", "budgetItems", _compact_rs_budget_item)
        counts["fundingGraphs"] = _shard_graphs_to_temp(graph_path, temp_root)

        context_specs = [
            ("policies", "policies-laws.jsonl", _compact_policy),
            ("subsidyRules", "subsidy-rules.jsonl", _compact_subsidy),
            ("projectRelations", "project-relations.jsonl", _compact_project_relation),
            ("logicNodes", "logic-model-nodes.jsonl", _compact_logic_node),
            ("logicObservations", "logic-model-observations.jsonl", _compact_logic_observation),
            ("logicRelations", "logic-model-relations.jsonl", _compact_logic_relation),
            ("evaluations", "evaluations.jsonl", _compact_evaluation),
            ("notes", "notes.jsonl", _compact_note),
        ]
        for cat, fn, func in context_specs:
            counts[cat] = _shard_rows_to_temp(nroot / fn, temp_root, "context", cat, func)

        spending_specs = [
            ("recipients", "recipients.jsonl", _compact_recipient),
            ("contracts", "contracts.jsonl", _compact_contract),
            ("expenseUses", "expense-uses.jsonl", _compact_expense_use),
            ("multiYearContracts", "multi-year-contracts.jsonl", _compact_multi_contract),
            ("indirectExpenses", "indirect-expenses.jsonl", _compact_indirect),
        ]
        for cat, fn, func in spending_specs:
            counts[cat] = _shard_rows_to_temp(nroot / fn, temp_root, "spending", cat, func)

        profile_bytes: dict[str, int] = defaultdict(int)
        profile_shards: dict[str, int] = defaultdict(int)
        availability: dict[str, set[str]] = {pid: set() for pid in projects}

        for profile in ("core", "context", "spending"):
            profile_dir = temp_root / profile
            if not profile_dir.exists():
                continue
            for temp_path in sorted(profile_dir.glob("*.jsonl")):
                shard = temp_path.stem
                bundles: dict[str, dict[str, Any]] = {}
                with temp_path.open(encoding="utf-8") as f:
                    for line in f:
                        row = json.loads(line)
                        pid = row["projectId"]
                        cat = row["category"]
                        value = row["value"]
                        b = bundles.setdefault(pid, {})
                        if cat in {"project", "fundingGraph"}:
                            b[cat] = value
                        else:
                            b.setdefault(cat, []).append(value)
                        availability.setdefault(pid, set()).add(profile)
                if bundles:
                    target = out / profile / f"{shard}.json.gz"
                    profile_bytes[profile] += _write_gzip_json(target, bundles)
                    profile_shards[profile] += 1

        index_rows: list[dict[str, Any]] = []
        all_pids = sorted(projects, key=lambda s: (int(s) if s.isdigit() else 10**30, s))
        for pid in all_pids:
            project = projects[pid]
            row = _pick(project, ("projectId", "projectName", "ministry", "bureau", "startYear", "endYear", "officialProjectUrl"))
            row["shard"] = _rs_shard(pid)
            row["profiles"] = sorted(availability.get(pid, {"core"}))
            if index_budget.get(pid):
                row["budget"] = index_budget[pid]
            metrics = graph_metrics.get(pid)
            if metrics:
                row["graph"] = _pick(metrics, ("blockCount", "semanticEdgeCount", "hasCycle", "weakComponentCount", "maxOutDegree", "orphanBlockIds", "externalRootBlockIds", "indirectExpenseCount"))
            links = project_links.get(pid, [])
            if links:
                by_fy = Counter(str(x["fiscalYear"]) for x in links)
                row["mofLinkCounts"] = dict(sorted(by_fy.items()))
            index_rows.append(row)

        index_obj = {
            "schemaVersion": SCHEMA_VERSION,
            "publishSchemaVersion": PUBLISH_SCHEMA_VERSION,
            "reviewYear": review_year,
            "projectCount": len(index_rows),
            "projects": index_rows,
        }
        index_bytes = _write_gzip_json(out / "index.json.gz", index_obj)
        manifest_obj = {
            "schemaVersion": SCHEMA_VERSION,
            "publishSchemaVersion": PUBLISH_SCHEMA_VERSION,
            "reviewYear": review_year,
            "projectCount": len(index_rows),
            "shardAlgorithm": "sha256('rs-project:' + projectId) first 2 hex chars",
            "index": "index.json.gz",
            "profiles": {p: {"pathTemplate": f"{p}/{{shard}}.json.gz", "shardCount": profile_shards[p], "compressedBytes": profile_bytes[p]} for p in ("core", "context", "spending")},
            "normalizedRecordCounts": counts,
            "linkProducts": link_products,
        }
        manifest_bytes = _write_json(out / "manifest.json", manifest_obj)
        return {
            "reviewYear": review_year,
            "projectCount": len(index_rows),
            "indexCompressedBytes": index_bytes,
            "manifestBytes": manifest_bytes,
            "profiles": manifest_obj["profiles"],
        }
    finally:
        shutil.rmtree(temp_root, ignore_errors=True)


def _mof_section_meta(fiscal_year: int, row: dict[str, Any]) -> dict[str, Any]:
    section_id = _mof_section_id(fiscal_year, row)
    values = _mof_section_tuple(row)
    keys = ("accountType", "ministry", "organization", "specialAccount", "subAccount", "agency", "sectionCode", "sectionName")
    out = {"id": section_id, "fiscalYear": fiscal_year, "shard": section_id[:2]}
    out.update({k: v for k, v in zip(keys, values) if v})
    return out


def publish_mof_year(work_root: Path, public_root: Path, fiscal_year: int, review_years: list[int]) -> tuple[dict[str, Any] | None, dict[str, dict[str, Any]]]:
    nroot = work_root / "normalized" / "mof" / f"fy{fiscal_year}"
    droot = work_root / "derived" / "mof" / f"fy{fiscal_year}"
    records_path = nroot / "budget-items.jsonl"
    events_path = droot / "budget-events.jsonl"
    if not records_path.exists() or not events_path.exists():
        return None, {}
    out = public_root / "data" / "v2" / "mof" / f"fy{fiscal_year}"
    if out.exists(): shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)

    records: dict[str, dict[str, Any]] = {}
    section_meta: dict[str, dict[str, Any]] = {}
    section_records: dict[str, list[str]] = defaultdict(list)
    record_section: dict[str, str] = {}
    record_item: dict[str, str] = {}
    item_meta: dict[str, dict[str, Any]] = {}
    for row in read_jsonl(records_path):
        rid = row["recordId"]
        sid = _mof_section_id(fiscal_year, row)
        iid = _mof_item_id(fiscal_year, row)
        record_section[rid] = sid
        record_item[rid] = iid
        section_meta.setdefault(sid, _mof_section_meta(fiscal_year, row))
        item_meta.setdefault(iid, {"id": iid, "name": row.get("subItemName", ""), **({"code": row.get("subItemCode")} if row.get("subItemCode") else {})})
        source = _compact_source(row.get("source"))
        records[rid] = {
            "id": rid,
            "itemId": iid,
            "phase": row.get("phase"),
            "budgetStatus": row.get("budgetStatus"),
            "revision": row.get("revision"),
            "sourceAmountColumn": row.get("sourceAmountColumn"),
            "source": source,
        }
        section_records[sid].append(rid)

    section_event_groups: dict[str, dict[tuple[Any, ...], dict[str, Any]]] = defaultdict(dict)
    section_stages: dict[str, set[str]] = defaultdict(set)
    section_amounts: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    section_group_amounts: dict[str, dict[tuple[Any, ...], int]] = defaultdict(lambda: defaultdict(int))
    event_count: dict[str, int] = defaultdict(int)
    for ev in read_jsonl(events_path):
        source_ids = [r for r in ev.get("sourceRecordIds") or [] if r in record_section]
        sids = sorted({record_section[r] for r in source_ids})
        if not sids:
            # Fall back to the event scope for derived events that may lack a directly mapped record.
            sid = _mof_section_id(fiscal_year, ev)
            sids = [sid]
            section_meta.setdefault(sid, _mof_section_meta(fiscal_year, ev))
        for sid in sids:
            key = (ev.get("eventType"), ev.get("budgetStatus"), ev.get("revision"))
            group = section_event_groups[sid].setdefault(key, {
                "eventType": ev.get("eventType"),
                **({"budgetStatus": ev.get("budgetStatus")} if ev.get("budgetStatus") else {}),
                **({"revision": ev.get("revision")} if ev.get("revision") is not None else {}),
                "amountYen": 0,
                "evidence": [],
            })
            group["amountYen"] += int(ev.get("amountYen") or 0)
            item_ids = sorted({record_item[r] for r in source_ids if r in record_item})
            evidence = {
                "eventId": ev.get("eventId"),
                "amountYen": int(ev.get("amountYen") or 0),
                "itemName": ev.get("subItemName", ""),
                "itemIds": item_ids,
                "recordIds": source_ids,
            }
            if ev.get("submittedAmountYen") is not None: evidence["submittedAmountYen"] = ev.get("submittedAmountYen")
            if ev.get("enactedAmountYen") is not None: evidence["enactedAmountYen"] = ev.get("enactedAmountYen")
            group["evidence"].append(evidence)
            section_stages[sid].add(ev.get("eventType", ""))
            section_amounts[sid][ev.get("eventType", "")] += int(ev.get("amountYen") or 0)
            section_group_amounts[sid][key] += int(ev.get("amountYen") or 0)
            event_count[sid] += 1

    section_relations: dict[str, list[dict[str, Any]]] = defaultdict(list)
    rel_path = droot / "identity-relations.jsonl"
    if rel_path.exists():
        for rel in read_jsonl(rel_path):
            src_records = [r for r in rel.get("sourceRecordIds") or [] if r in record_section]
            tgt_records = [r for r in rel.get("targetRecordIds") or [] if r in record_section]
            sids = sorted({record_section[r] for r in src_records + tgt_records})
            compact = {
                "relationId": rel.get("relationId"),
                "relationType": rel.get("relationType"),
                "evidenceMethod": rel.get("evidenceMethod"),
                "sourceStage": rel.get("sourceStage"),
                "targetStage": rel.get("targetStage"),
                "sourceSectionIds": sorted({record_section[r] for r in src_records}),
                "targetSectionIds": sorted({record_section[r] for r in tgt_records}),
                "sourceItemIds": sorted({record_item[r] for r in src_records}),
                "targetItemIds": sorted({record_item[r] for r in tgt_records}),
            }
            for sid in sids:
                section_relations[sid].append(compact)

    section_links: dict[str, list[dict[str, Any]]] = defaultdict(list)
    link_products: list[dict[str, Any]] = []
    link_dir = work_root / "derived" / "links"
    for review_year in review_years:
        link_path = link_dir / f"mof-rs-review-{review_year}-fy{fiscal_year}.jsonl"
        if not link_path.exists(): continue
        groups = 0
        projects: set[str] = set()
        for link in read_jsonl(link_path):
            mof_records = [r for r in link.get("mofRecordIds") or [] if r in record_section]
            sids = sorted({record_section[r] for r in mof_records})
            compact = {
                "linkId": link.get("linkId"),
                "reviewYear": review_year,
                "phase": link.get("phase"),
                "revision": link.get("revision"),
                "matchMethod": link.get("matchMethod"),
                "projectIds": [str(x) for x in link.get("projectIds") or []],
                "itemIds": sorted({record_item[r] for r in mof_records}),
                "mofAmountYen": link.get("mofAmountYen"),
                "rsAmountYen": link.get("rsAmountYen"),
                "differenceYen": link.get("differenceYen"),
            }
            for sid in sids:
                section_links[sid].append(compact)
            groups += 1
            projects.update(compact["projectIds"])
        link_products.append({"reviewYear": review_year, "fiscalYear": fiscal_year, "linkGroupCount": groups, "linkedProjectCount": len(projects)})

    index_rows: list[dict[str, Any]] = []
    details_by_shard: dict[str, dict[str, Any]] = defaultdict(dict)
    for sid, meta in sorted(section_meta.items()):
        rids = section_records.get(sid, [])
        iids = sorted({record_item[r] for r in rids if r in record_item})
        amounts = section_amounts.get(sid, {})
        idx = dict(meta)
        idx["itemCount"] = len(iids)
        idx["eventCount"] = event_count.get(sid, 0)
        idx["stages"] = sorted(x for x in section_stages.get(sid, set()) if x)
        # Keep only useful index measures. Initial submitted/enacted are separate snapshots;
        # never add them together. Explicit zero is retained where an event exists.
        grouped = section_group_amounts.get(sid, {})
        initial_submitted = sum(v for (typ, status, _rev), v in grouped.items() if typ == "initial_budget_state" and status == "submitted")
        initial_enacted = sum(v for (typ, status, _rev), v in grouped.items() if typ == "initial_budget_state" and status == "enacted")
        has_submitted = any(typ == "initial_budget_state" and status == "submitted" for typ, status, _rev in grouped)
        has_enacted = any(typ == "initial_budget_state" and status == "enacted" for typ, status, _rev in grouped)
        if has_submitted: idx["initialSubmittedYen"] = initial_submitted
        if has_enacted: idx["initialEnactedYen"] = initial_enacted
        if has_enacted or has_submitted:
            idx["initialYen"] = initial_enacted if has_enacted else initial_submitted
        for source_key, dest_key in [
            ("supplement_adjustment", "supplementDeltaYen"),
            ("settlement_budget_appropriation", "settlementBudgetYen"),
            ("current_budget_state", "currentBudgetYen"),
            ("spent", "spentYen"),
            ("carryover_out", "carryoverOutYen"),
            ("unused", "unusedYen"),
        ]:
            if source_key in amounts:
                idx[dest_key] = amounts[source_key]
        # The gap between post-supplement budget and the settlement-side budget appropriation
        # is real evidence of an intervening change, but its cause must not be guessed.
        # It may be transfer/reallocation/administrative reclassification etc. until an official
        # relation source classifies it. PID:4 is the key regression case (~-509.7bn).
        if "initialYen" in idx and "settlementBudgetYen" in idx:
            post_supplement = idx["initialYen"] + idx.get("supplementDeltaYen", 0)
            gap = idx["settlementBudgetYen"] - post_supplement
            if gap != 0:
                idx["unresolvedPreSettlementDeltaYen"] = gap
        links = section_links.get(sid, [])
        if links:
            idx["rsLinkCounts"] = dict(sorted(Counter(str(l["reviewYear"]) for l in links).items()))
            idx["rsProjectCount"] = len({pid for l in links for pid in l.get("projectIds", [])})
        index_rows.append(idx)

        sources: list[dict[str, Any]] = []
        source_index: dict[str, int] = {}
        compact_records: list[dict[str, Any]] = []
        for rid in rids:
            rec = records[rid]
            src = rec.pop("source", None)
            if src:
                skey = json.dumps(src, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                if skey not in source_index:
                    source_index[skey] = len(sources)
                    sources.append(src)
                rec = dict(rec)
                rec["sourceRef"] = source_index[skey]
            compact_records.append(rec)
        detail = {
            "section": meta,
            "items": [item_meta[i] for i in iids],
            "events": list(section_event_groups.get(sid, {}).values()),
            "records": compact_records,
            "sources": sources,
        }
        if idx.get("unresolvedPreSettlementDeltaYen") is not None:
            detail["stageGaps"] = [{
                "from": "post_supplement_budget",
                "to": "settlement_budget_appropriation",
                "deltaYen": idx["unresolvedPreSettlementDeltaYen"],
                "classification": "unresolved",
                "note": "Do not classify as transfer/reserve without supporting official relation evidence.",
            }]
        if section_relations.get(sid): detail["relations"] = section_relations[sid]
        if links: detail["rsLinks"] = links
        details_by_shard[sid[:2]][sid] = detail

    compressed_bytes = 0
    max_shard_bytes = 0
    for shard, values in sorted(details_by_shard.items()):
        n = _write_gzip_json(out / "sections" / f"{shard}.json.gz", values)
        compressed_bytes += n
        max_shard_bytes = max(max_shard_bytes, n)
    index_obj = {"schemaVersion": SCHEMA_VERSION, "publishSchemaVersion": PUBLISH_SCHEMA_VERSION, "fiscalYear": fiscal_year, "sectionCount": len(index_rows), "sections": index_rows}
    index_bytes = _write_gzip_json(out / "index.json.gz", index_obj)
    manifest = {
        "schemaVersion": SCHEMA_VERSION,
        "publishSchemaVersion": PUBLISH_SCHEMA_VERSION,
        "fiscalYear": fiscal_year,
        "sectionCount": len(index_rows),
        "shardAlgorithm": "sectionId first 2 hex chars",
        "index": "index.json.gz",
        "sections": {"pathTemplate": "sections/{shard}.json.gz", "shardCount": len(details_by_shard), "compressedBytes": compressed_bytes, "maxShardCompressedBytes": max_shard_bytes},
        "linkProducts": link_products,
    }
    manifest_bytes = _write_json(out / "manifest.json", manifest)
    return ({"fiscalYear": fiscal_year, "sectionCount": len(index_rows), "indexCompressedBytes": index_bytes, "manifestBytes": manifest_bytes, "sections": manifest["sections"]}, record_section)


def publish_link_product(work_root: Path, public_root: Path, review_year: int, fiscal_year: int, record_section: dict[str, str]) -> dict[str, Any] | None:
    path = work_root / "derived" / "links" / f"mof-rs-review-{review_year}-fy{fiscal_year}.jsonl"
    if not path.exists(): return None
    links: list[dict[str, Any]] = []
    project_ids: set[str] = set()
    section_ids: set[str] = set()
    for row in read_jsonl(path):
        sids = sorted({record_section[r] for r in row.get("mofRecordIds") or [] if r in record_section})
        pids = [str(x) for x in row.get("projectIds") or []]
        links.append({
            "linkId": row.get("linkId"),
            "phase": row.get("phase"),
            "revision": row.get("revision"),
            "matchMethod": row.get("matchMethod"),
            "sectionIds": sids,
            "projectIds": pids,
            "mofAmountYen": row.get("mofAmountYen"),
            "rsAmountYen": row.get("rsAmountYen"),
            "differenceYen": row.get("differenceYen"),
        })
        project_ids.update(pids); section_ids.update(sids)
    out = public_root / "data" / "v2" / "links" / f"review-{review_year}-fy{fiscal_year}"
    if out.exists(): shutil.rmtree(out)
    out.mkdir(parents=True, exist_ok=True)
    bytes_ = _write_gzip_json(out / "links.json.gz", {"schemaVersion": SCHEMA_VERSION, "publishSchemaVersion": PUBLISH_SCHEMA_VERSION, "reviewYear": review_year, "fiscalYear": fiscal_year, "links": links})
    manifest = {"schemaVersion": SCHEMA_VERSION, "publishSchemaVersion": PUBLISH_SCHEMA_VERSION, "reviewYear": review_year, "fiscalYear": fiscal_year, "linkGroupCount": len(links), "projectCount": len(project_ids), "sectionCount": len(section_ids), "compressedBytes": bytes_, "file": "links.json.gz"}
    _write_json(out / "manifest.json", manifest)
    return manifest


def _dir_size(path: Path) -> int:
    return sum(p.stat().st_size for p in path.rglob("*") if p.is_file()) if path.exists() else 0


def publish_all(work_root: Path, public_root: Path, fiscal_years: list[int], review_years: list[int]) -> dict[str, Any]:
    v2root = public_root / "data" / "v2"
    if v2root.exists(): shutil.rmtree(v2root)
    v2root.mkdir(parents=True, exist_ok=True)

    rs_products: list[dict[str, Any]] = []
    for ry in review_years:
        result = publish_rs_year(work_root, public_root, ry)
        if result: rs_products.append(result)

    mof_products: list[dict[str, Any]] = []
    record_sections: dict[int, dict[str, str]] = {}
    for fy in fiscal_years:
        result, mapping = publish_mof_year(work_root, public_root, fy, review_years)
        if result:
            mof_products.append(result)
            record_sections[fy] = mapping

    link_products: list[dict[str, Any]] = []
    for ry in review_years:
        for fy in fiscal_years:
            if fy not in record_sections: continue
            result = publish_link_product(work_root, public_root, ry, fy, record_sections[fy])
            if result: link_products.append(result)

    manifest = {
        "schemaVersion": SCHEMA_VERSION,
        "publishSchemaVersion": PUBLISH_SCHEMA_VERSION,
        "compression": "gzip-json (manual browser decompression or equivalent client helper)",
        "sharding": {"hexBuckets": SHARD_COUNT},
        "mof": mof_products,
        "rs": rs_products,
        "links": link_products,
    }
    _write_json(v2root / "manifest.json", manifest)
    manifest["totalPublicBytes"] = _dir_size(v2root)
    _write_json(v2root / "manifest.json", manifest)
    return manifest
