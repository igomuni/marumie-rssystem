from __future__ import annotations

import gzip
import json
from pathlib import Path
from typing import Any


def _load(path: Path) -> Any:
    if path.suffix == '.gz':
        return json.loads(gzip.decompress(path.read_bytes()))
    return json.loads(path.read_text(encoding='utf-8'))


def validate_public(public_root: Path) -> dict[str, Any]:
    root = public_root / 'data' / 'v2'
    manifest = _load(root / 'manifest.json')
    errors: list[str] = []
    warnings: list[str] = []
    stats: dict[str, Any] = {'files': 0, 'bytes': 0, 'maxFileBytes': 0}
    for p in root.rglob('*'):
        if not p.is_file(): continue
        stats['files'] += 1; stats['bytes'] += p.stat().st_size; stats['maxFileBytes'] = max(stats['maxFileBytes'], p.stat().st_size)
        if p.suffix == '.gz':
            try: _load(p)
            except Exception as e: errors.append(f'invalid gzip/json: {p.relative_to(root)}: {e}')
        if p.stat().st_size > 1024*1024:
            warnings.append(f'large static file >1MiB: {p.relative_to(root)} ({p.stat().st_size} bytes)')

    # MOF: every index row resolves to exactly one section detail.
    mof_ids_by_year: dict[int, set[str]] = {}
    for m in manifest.get('mof', []):
        fy = int(m['fiscalYear'])
        base = root / 'mof' / f'fy{fy}'
        idx = _load(base / 'index.json.gz')
        ids: set[str] = set()
        for row in idx.get('sections', []):
            sid = row['id']; shard = row['shard']
            shard_path = base / 'sections' / f'{shard}.json.gz'
            if not shard_path.exists(): errors.append(f'MOF missing shard FY{fy}: {shard}') ; continue
            data = _load(shard_path)
            if sid not in data: errors.append(f'MOF index points to missing section FY{fy}: {sid}')
            if sid in ids: errors.append(f'MOF duplicate section id FY{fy}: {sid}')
            ids.add(sid)
        mof_ids_by_year[fy] = ids

    # RS: every index project resolves to core shard.
    rs_ids_by_year: dict[int, set[str]] = {}
    rs_core_cache: dict[tuple[int,str], dict[str,Any]] = {}
    for r in manifest.get('rs', []):
        ry = int(r['reviewYear'])
        base = root / 'rs' / f'review-{ry}'
        idx = _load(base / 'index.json.gz')
        ids: set[str] = set()
        for row in idx.get('projects', []):
            pid = str(row['projectId']); shard = row['shard']
            key=(ry,shard)
            if key not in rs_core_cache:
                p=base/'core'/f'{shard}.json.gz'
                if not p.exists(): errors.append(f'RS missing core shard review-{ry}: {shard}'); rs_core_cache[key]={}
                else: rs_core_cache[key]=_load(p)
            if pid not in rs_core_cache[key]: errors.append(f'RS index points to missing project review-{ry}: {pid}')
            if pid in ids: errors.append(f'RS duplicate project id review-{ry}: {pid}')
            ids.add(pid)
        rs_ids_by_year[ry] = ids

    # Link product refs must point to existing published entities when those years are published.
    for l in manifest.get('links', []):
        ry=int(l['reviewYear']); fy=int(l['fiscalYear'])
        path=root/'links'/f'review-{ry}-fy{fy}'/'links.json.gz'
        data=_load(path)
        for link in data.get('links',[]):
            if fy in mof_ids_by_year:
                for sid in link.get('sectionIds',[]):
                    if sid not in mof_ids_by_year[fy]: errors.append(f'link missing MOF section review-{ry}-fy{fy}: {sid}')
            if ry in rs_ids_by_year:
                for pid in link.get('projectIds',[]):
                    if str(pid) not in rs_ids_by_year[ry]: errors.append(f'link missing RS project review-{ry}: {pid}')

    return {'ok': not errors, 'errors': errors, 'warnings': warnings, 'stats': stats}
