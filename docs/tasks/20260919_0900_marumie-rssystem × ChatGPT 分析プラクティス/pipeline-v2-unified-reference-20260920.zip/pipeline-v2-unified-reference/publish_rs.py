#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil
from collections import defaultdict
from pathlib import Path

def rows(path):
    if not path.exists(): return
    with path.open(encoding='utf-8') as f:
        for line in f:
            if line.strip(): yield json.loads(line)

def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':')),encoding='utf-8')

def compact_project(x):
    keys=['projectId','projectName','ministry','bureau','department','division','office','team','unit','accountClass','majorExpense','overview','currentIssues','startYear','endYear','noPlannedEnd','officialProjectUrl','legacyProjectNumber','implementationMethods']
    return {k:x.get(k) for k in keys if x.get(k) not in (None,'',{},[])}

def compact_summary(x):
    amounts={k:v for k,v in (x.get('amounts') or {}).items() if v not in (None,0)}
    out={'fy':x.get('fiscalYear'),'scope':x.get('scopeLevel'),'amounts':amounts}
    for k,short in [('account','account'),('accountType','accountType'),('subAccount','subAccount'),('changeReason','changeReason'),('specialNotes','notes')]:
        if x.get(k): out[short]=x[k]
    return out

def compact_contract(x):
    out={'block':x.get('blockId'),'recipient':x.get('recipientNameRaw'),'amount':x.get('amountYen')}
    for k,short in [('corporateNumberRaw','corpNo'),('summary','summary'),('method','method'),('methodDetail','methodDetail'),('bidderCount','bidders'),('winningRate','winningRate'),('singleBidReason','singleBidReason')]:
        if x.get(k) not in (None,''): out[short]=x[k]
    return out

def compact_graph(g):
    nodes=[]
    for n in g.get('nodes',[]):
        z={'id':n.get('nodeId'),'type':n.get('nodeType'),'name':n.get('name')}
        for k,short in [('blockId','block'),('roles','roles'),('totalAmountValuesYen','amounts'),('recipientCountValues','recipientCounts')]:
            if n.get(k): z[short]=n[k]
        nodes.append(z)
    edges=[]
    # semanticEdges preferred; fallback edges/relation groups
    src=g.get('semanticEdges') or g.get('edges') or []
    for e in src:
        z={'from':e.get('fromNodeId') or e.get('sourceNodeId') or e.get('from'),'to':e.get('toNodeId') or e.get('targetNodeId') or e.get('to')}
        for k,short in [('relationLabels','labels'),('notes','notes'),('evidenceCount','evidenceCount'),('responsibleOrganizationSpend','responsibleOrgSpend')]:
            if e.get(k) not in (None,'',[],0,False): z[short]=e[k]
        edges.append(z)
    m=g.get('metrics') or {}
    metrics={k:m.get(k) for k in ['hasCycle','weakComponentCount','maxOutDegree','maxInDegree','orphanBlockIds','externalRootBlockIds','duplicateRelationPairCount','indirectExpenseCount'] if m.get(k) not in (None,False,0,[],1)}
    return {'nodes':nodes,'edges':edges,'metrics':metrics}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--work-root',type=Path,required=True)
    ap.add_argument('--public-root',type=Path,required=True)
    ap.add_argument('--year',type=int,default=2025)
    ap.add_argument('--include-contracts',action='store_true')
    a=ap.parse_args()
    out=a.public_root/'data'/'v2'/'rs'/f'review-{a.year}'
    if out.exists(): shutil.rmtree(out)
    (out/'projects').mkdir(parents=True)
    nroot=a.work_root/'normalized'/'rs'/f'review-{a.year}'
    droot=a.work_root/'derived'/'rs'/f'review-{a.year}'
    projects={x['projectId']:compact_project(x) for x in rows(nroot/'projects.jsonl')}
    summaries=defaultdict(list)
    for x in rows(nroot/'budget-summaries.jsonl'):
        summaries[x['projectId']].append(compact_summary(x))
    graphs={x['projectId']:compact_graph(x) for x in rows(droot/'funding-graphs.jsonl')}
    contracts=defaultdict(list)
    if a.include_contracts:
        for x in rows(nroot/'contracts.jsonl'):
            contracts[x['projectId']].append(compact_contract(x))
    index=[]
    pids=sorted(set(projects)|set(graphs)|set(summaries), key=lambda s:int(s) if s.isdigit() else s)
    for pid in pids:
        p=projects.get(pid,{})
        idx={k:p.get(k) for k in ['projectId','projectName','ministry','bureau','startYear','endYear','officialProjectUrl'] if p.get(k) not in (None,'')}
        if pid in graphs:
            m=graphs[pid]['metrics']; idx['graph']={'nodes':len(graphs[pid]['nodes']),'edges':len(graphs[pid]['edges']),**m}
        index.append(idx)
        bundle={'project':p}
        if summaries.get(pid): bundle['budgetSummaries']=summaries[pid]
        if pid in graphs: bundle['fundingGraph']=graphs[pid]
        if contracts.get(pid): bundle['contracts']=contracts[pid]
        dump(out/'projects'/f'{pid}.json',bundle)
    dump(out/'index.json',{'reviewYear':a.year,'projectCount':len(index),'projects':index})
    dump(out/'manifest.json',{'schemaVersion':1,'reviewYear':a.year,'projectCount':len(index),'layout':'projects/{projectId}.json','includesContracts':a.include_contracts})
    print(out)

if __name__=='__main__': main()
