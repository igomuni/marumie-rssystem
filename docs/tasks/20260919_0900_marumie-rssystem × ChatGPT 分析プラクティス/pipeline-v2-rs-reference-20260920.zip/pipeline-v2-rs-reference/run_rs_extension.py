#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from pipeline_v2.normalize_rs import discover_rs_years, normalize_rs
from pipeline_v2.funding_graph import build_funding_graphs


def main() -> None:
    p = argparse.ArgumentParser(description='RS-only Pipeline V2 extension reference implementation')
    p.add_argument('--raw-root', type=Path, required=True)
    p.add_argument('--output-root', type=Path, required=True)
    p.add_argument('--review-years', nargs='*', type=int, help='Omit to discover available download-csv/sheets years')
    p.add_argument('--skip-normalize', action='store_true')
    p.add_argument('--skip-graph', action='store_true')
    args = p.parse_args()

    requested = set(args.review_years) if args.review_years else None
    years = discover_rs_years(args.raw_root, requested)
    if not years:
        raise SystemExit('No RS years found under raw-root/rssystem.go.jp/{download-csv,sheets}')
    print('RS source years:', ', '.join(map(str, years)))
    args.output_root.mkdir(parents=True, exist_ok=True)

    if not args.skip_normalize:
        print('[1/2] normalize RS sources')
        normalize_rs(args.raw_root, args.output_root, set(years))
    if not args.skip_graph:
        print('[2/2] build RS funding graphs')
        # Graph builder safely emits empty/absent products for sheets-only years.
        summaries = build_funding_graphs(args.output_root, years)
        print(json.dumps(summaries, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
