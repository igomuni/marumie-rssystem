#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import io
import json
import re
import unicodedata
import zipfile
from collections import Counter, defaultdict, deque
from pathlib import Path
from typing import Any, Iterable

from pipeline_v2.common import canonical_project_id, parse_number, read_jsonl
from pipeline_v2.normalize_rs import DATASETS, _find_zip

STRESS_PIDS = ['1','4','12','1409','2776','142','500','1406','3339','333','18','747','1082','4162','1675']


def _decode(raw: bytes) -> str:
    try:
        return raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        return raw.decode('cp932')


def raw_inventory(raw_root: Path, year: int) -> dict[str, Any]:
    year_dir = raw_root / 'rssystem.go.jp' / 'download-csv' / str(year)
    out: dict[str, Any] = {}
    for code, (dataset_name, _) in DATASETS.items():
        p = _find_zip(year_dir, code, year)
        if not p:
            out[code] = {'available': False, 'datasetName': dataset_name}
            continue
        with zipfile.ZipFile(p) as zf:
            names = [n for n in zf.namelist() if n.lower().endswith('.csv')]
            if not names:
                out[code] = {'available': False, 'datasetName': dataset_name, 'reason': 'no_csv_entry'}
                continue
            entry = sorted(names)[0]
            reader = csv.reader(io.StringIO(_decode(zf.read(entry))))
            headers = next(reader)
            rows = 0
            nonempty = [0] * len(headers)
            for row in reader:
                rows += 1
                for i, value in enumerate(row[:len(headers)]):
                    if value.strip():
                        nonempty[i] += 1
        out[code] = {
            'available': True,
            'datasetName': dataset_name,
            'file': p.name,
            'zipEntry': entry,
            'rowCount': rows,
            'columnCount': len(headers),
            'nonEmptyColumnCount': sum(1 for n in nonempty if n),
        }
    return out


def _load_graphs(out_root: Path, year: int) -> dict[str, dict[str, Any]]:
    p = out_root / 'derived' / 'rs' / f'review-{year}' / 'funding-graphs.jsonl'
    return {r['projectId']: r for r in read_jsonl(p)}


def _jsonl_count(path: Path) -> int:
    if not path.exists():
        return 0
    with path.open('rb') as f:
        return sum(1 for _ in f)


def _selected_records(path: Path, pids: set[str]) -> dict[str, list[dict[str, Any]]]:
    out: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in read_jsonl(path):
        pid = str(r.get('projectId', ''))
        if pid in pids:
            out[pid].append(r)
    return out


def block_integrity(out_root: Path, year: int) -> dict[str, Any]:
    norm = out_root / 'normalized' / 'rs' / f'review-{year}'
    blocks: dict[tuple[str,str], dict[str, Any]] = {}
    for b in read_jsonl(norm / 'spending-blocks.jsonl'):
        blocks[(b.get('projectId',''), b.get('blockId',''))] = b
    refs: set[tuple[str,str]] = set()
    missing: list[dict[str,Any]] = []
    mismatches: list[dict[str,Any]] = []
    pair_counts: Counter[tuple[str,str,str]] = Counter()
    for r in read_jsonl(norm / 'funding-relations.jsonl'):
        pid = r.get('projectId','')
        sb = r.get('sourceBlockId')
        tb = r.get('targetBlockId')
        if sb:
            refs.add((pid,sb))
            b = blocks.get((pid,sb))
            if not b:
                missing.append({'projectId':pid,'role':'source','blockId':sb,'relationId':r.get('relationId')})
            else:
                source_name = r.get('sourceBlockName','')
                if source_name and b.get('blockName') and _norm(source_name) != _norm(b.get('blockName','')):
                    mismatches.append({'projectId':pid,'blockId':sb,'side':'source','blockName5_1':b.get('blockName'),'blockName5_2':source_name})
        if tb:
            refs.add((pid,tb))
            b = blocks.get((pid,tb))
            if not b:
                missing.append({'projectId':pid,'role':'target','blockId':tb,'relationId':r.get('relationId')})
            else:
                target_name = r.get('targetBlockName','')
                if target_name and b.get('blockName') and _norm(target_name) != _norm(b.get('blockName','')):
                    mismatches.append({'projectId':pid,'blockId':tb,'side':'target','blockName5_1':b.get('blockName'),'blockName5_2':target_name})
        src_key = sb or ('@responsible' if r.get('fromResponsibleOrganization') is True else '@unknown')
        pair_counts[(pid,str(src_key),str(tb or ''))] += 1
    orphans = sorted(set(blocks) - refs)
    return {
        'blockCount': len(blocks),
        'referencedBlockCount': len(refs),
        'orphanBlockCount': len(orphans),
        'orphanProjectCount': len({p for p,_ in orphans}),
        'missingReferencedBlockCount': len(missing),
        'blockNameMismatchCount': len(mismatches),
        'duplicateRelationPairCount': sum(1 for c in pair_counts.values() if c > 1),
        'duplicateRelationEvidenceExtraCount': sum(c-1 for c in pair_counts.values() if c > 1),
        'missingReferencedBlockExamples': missing[:10],
        'blockNameMismatchExamples': mismatches[:10],
    }


def _norm(value: str) -> str:
    return re.sub(r'\s+','',unicodedata.normalize('NFKC', value or ''))


def stress_report(out_root: Path, year: int) -> dict[str, Any]:
    graphs = _load_graphs(out_root, year)
    norm = out_root / 'normalized' / 'rs' / f'review-{year}'
    blocks = _selected_records(norm / 'spending-blocks.jsonl', set(STRESS_PIDS))
    relations = _selected_records(norm / 'funding-relations.jsonl', set(STRESS_PIDS))
    indirect = _selected_records(norm / 'indirect-expenses.jsonl', set(STRESS_PIDS))
    result: dict[str,Any] = {}
    for pid in STRESS_PIDS:
        g = graphs.get(pid)
        result[pid] = {
            'present': bool(g),
            'projectName': g.get('projectName','') if g else '',
            'metrics': g.get('metrics',{}) if g else {},
            'blockSummaryRows': {b.get('blockId',''): b.get('summaryRowCount',0) for b in blocks.get(pid,[])},
            'relationEvidenceCountNormalized': len(relations.get(pid,[])),
            'indirectExpenseCountNormalized': len(indirect.get(pid,[])),
        }
    return result


def pid4_budget_check(out_root: Path, year: int) -> dict[str, Any]:
    p = out_root / 'normalized' / 'rs' / f'review-{year}' / 'budget-events.jsonl'
    target = []
    reserve = []
    for r in read_jsonl(p):
        if r.get('projectId') != '4' or r.get('fiscalYear') != 2024:
            continue
        if r.get('eventType') == 'adjustment' and r.get('sourceAmountColumn') in {'予備費等（合計）','予備費等1'} and r.get('amountYen') == -509690849950:
            target.append(r)
        if r.get('eventType') == 'reserve':
            reserve.append(r)
    return {
        'adjustmentMatches': len(target),
        'reserveEventCountForPid4Fy2024': len(reserve),
        'examples': [{k:r.get(k) for k in ['scopeLevel','accountClass','sourceAmountColumn','amountYen','eventType','semanticStatus']} for r in target[:5]],
    }


def sheets_check(out_root: Path, year: int) -> dict[str, Any]:
    p = out_root / 'normalized' / 'rs' / f'review-{year}' / 'review-sheets.jsonl'
    count = urls = form2 = form2_urls = 0
    pid4 = []
    new_examples=[]
    for r in read_jsonl(p):
        count += 1
        if r.get('officialProjectUrl'): urls += 1
        if r.get('sheetForm') == 'form2':
            form2 += 1
            if r.get('officialProjectUrl'): form2_urls += 1
            if len(new_examples)<5 and r.get('nextRequestYen') is not None:
                new_examples.append({k:r.get(k) for k in ['projectId','projectIdRaw','projectName','nextRequestFiscalYear','nextRequestYen','officialProjectUrl']})
        if r.get('projectId') == '4':
            pid4.append({k:r.get(k) for k in ['projectId','projectIdRaw','projectName','sheetForm','officialProjectUrl','currentInitialYen','nextRequestYen']})
    return {'rowCount':count,'officialProjectUrlCount':urls,'form2RowCount':form2,'form2OfficialProjectUrlCount':form2_urls,'pid4':pid4,'newRequestExamples':new_examples}


def build_report(raw_root: Path, out_root: Path) -> dict[str, Any]:
    inv2025 = raw_inventory(raw_root, 2025)
    graph_summary_path = out_root/'derived'/'rs'/'review-2025'/'funding-graph-summary.json'
    graph_summary = json.loads(graph_summary_path.read_text()) if graph_summary_path.exists() else {}
    normalized_counts = {}
    norm2025 = out_root/'normalized'/'rs'/'review-2025'
    for p in sorted(norm2025.glob('*.jsonl')):
        normalized_counts[p.stem] = _jsonl_count(p)
    checks = {
        'canonicalProjectId': {
            '000004': canonical_project_id('000004'),
            '4': canonical_project_id('4'),
            'equal': canonical_project_id('000004') == canonical_project_id('4'),
        },
        'blankVsZero': {
            'blank': parse_number(''),
            'zero': parse_number('0'),
            'decimalZero': parse_number('0.0'),
        },
        'pid4BudgetAdjustment': pid4_budget_check(out_root, 2025),
        'blockIntegrity': block_integrity(out_root, 2025),
        'sheets2026': sheets_check(out_root, 2026),
    }
    stress = stress_report(out_root, 2025)
    assertions = {
        'all15CsvAvailable2025': all(inv2025[c].get('available') for c in DATASETS),
        'canonical000004Equals4': checks['canonicalProjectId']['equal'],
        'blankPreservedAsNull': checks['blankVsZero']['blank'] is None,
        'explicitZeroPreserved': checks['blankVsZero']['zero'] == 0 and checks['blankVsZero']['decimalZero'] == 0,
        'pid4AdjustmentNeutral': checks['pid4BudgetAdjustment']['adjustmentMatches'] >= 1 and checks['pid4BudgetAdjustment']['reserveEventCountForPid4Fy2024'] == 0,
        'no5_2ReferencesMissing5_1Block': checks['blockIntegrity']['missingReferencedBlockCount'] == 0,
        'noBlockNameMismatch5_1vs5_2': checks['blockIntegrity']['blockNameMismatchCount'] == 0,
        'pid1409HasCycle': stress['1409']['metrics'].get('hasCycle') is True,
        'pid2776HasNoResponsibleRoot': stress['2776']['metrics'].get('hasResponsibleOrganizationRoot') is False,
        'pid333Disconnected': stress['333']['metrics'].get('weakComponentCount',0) >= 2,
        'pid3339Has30Orphans': len(stress['3339']['metrics'].get('orphanBlockIds',[])) == 30,
        'pid747DuplicateRelationsPreserved': stress['747']['metrics'].get('duplicateRelationPairCount',0) > 0,
        'pid1082HighFanout': stress['1082']['metrics'].get('maxOutDegree',0) >= 55,
        'pid4162IndirectExpenses': stress['4162']['metrics'].get('indirectExpenseCount',0) >= 12,
        'pid1409DuplicateBlockSummary': stress['1409']['blockSummaryRows'].get('A',0) >= 2,
        'sheets2026HasOfficialUrls': checks['sheets2026']['officialProjectUrlCount'] > 0,
        'sheets2026HasNewRequests': checks['sheets2026']['form2RowCount'] > 0,
    }
    return {
        'schemaVersion': 1,
        'raw2025': inv2025,
        'normalized2025RecordCounts': normalized_counts,
        'fundingGraph2025': graph_summary,
        'checks': checks,
        'stressFixtures2025': stress,
        'assertions': assertions,
        'allAssertionsPassed': all(assertions.values()),
    }


def to_markdown(report: dict[str, Any]) -> str:
    a=report['assertions']; lines=[]
    lines += ['# Pipeline V2 RS拡張 参照実装 検証レポート','', '## 結論','']
    lines.append(f"- Acceptance assertions: **{sum(a.values())}/{len(a)} PASS**")
    lines.append(f"- Overall: **{'PASS' if report['allAssertionsPassed'] else 'FAIL'}**")
    lines += ['','## 2025 download-csv 15系統','', '| code | dataset | rows | cols |', '|---|---|---:|---:|']
    for code,(name,_) in DATASETS.items():
        r=report['raw2025'][code]; lines.append(f"| {code} | {name} | {r.get('rowCount','-'):,} | {r.get('columnCount','-')} |" if isinstance(r.get('rowCount'),int) else f"| {code} | {name} | - | - |")
    b=report['checks']['blockIntegrity']; g=report['fundingGraph2025']
    lines += ['','## 5-1 / 5-2 / Funding Graph','',
              f"- 5-1 block: **{b['blockCount']:,}**",
              f"- 5-2参照blockの5-1欠落: **{b['missingReferencedBlockCount']}**",
              f"- 5-1/5-2 block名不一致: **{b['blockNameMismatchCount']}**",
              f"- orphan block: **{b['orphanBlockCount']:,} / {b['orphanProjectCount']}事業**",
              f"- Funding graph projects: **{g.get('projectCount',0):,}**",
              f"- cycleあり: **{g.get('projectsWithCycles',0)}事業**",
              f"- duplicate source-target relationあり: **{g.get('projectsWithDuplicateRelationPairs',0)}事業**",
              f"- indirect expense rows: **{g.get('indirectExpenseCount',0):,}**",
              '']
    p4=report['checks']['pid4BudgetAdjustment']
    lines += ['## PID:4 semantic regression','',
              f"- `-509,690,849,950` は `adjustment` として **{p4['adjustmentMatches']}件**確認（project total / account evidence）",
              f"- PID:4 FY2024 の `reserve` event: **{p4['reserveEventCountForPid4Fy2024']}件**",
              '- `予備費等` を Normalized で reserve と断定しない条件を満たす。','']
    lines += ['## Stress fixtures','', '| PID | blocks | rel evidence | cycle | weak components | max out | max in | orphan | duplicate pairs | indirect |', '|---:|---:|---:|:---:|---:|---:|---:|---:|---:|---:|']
    for pid in STRESS_PIDS:
        s=report['stressFixtures2025'][pid]; m=s['metrics']; lines.append(f"| {pid} | {m.get('blockCount',0)} | {m.get('relationEvidenceCount',0)} | {'yes' if m.get('hasCycle') else 'no'} | {m.get('weakComponentCount',0)} | {m.get('maxOutDegree',0)} | {m.get('maxInDegree',0)} | {len(m.get('orphanBlockIds',[]))} | {m.get('duplicateRelationPairCount',0)} | {m.get('indirectExpenseCount',0)} |")
    sh=report['checks']['sheets2026']; lines += ['','## 2026 sheets-only normalization','',f"- form1/2 normalized rows: **{sh['rowCount']:,}**",f"- official project URL: **{sh['officialProjectUrlCount']:,}**",f"- form2 new-request rows: **{sh['form2RowCount']:,}**",f"- form2 URLあり: **{sh['form2OfficialProjectUrlCount']:,}**",'- 2026 download-csvが無くても sheets だけで normalize できることを確認。','']
    lines += ['## Assertions','']
    for k,v in a.items(): lines.append(f"- [{'x' if v else ' '}] `{k}`")
    lines += ['','## 注意','', '- Funding graph の `weakComponentCount` は孤立blockも1 componentとして数える。PID:3339は30孤立blockなので30 components。', '- 5-2 edgeに金額は付与していない。金額は5-1/5-3等の別証拠と混同しない。', '- 2026は手元アーカイブ上 `sheets` のみで、download-csv 15系統は存在しない。']
    return '\n'.join(lines)+'\n'


def main() -> None:
    ap=argparse.ArgumentParser(); ap.add_argument('--raw-root',type=Path,required=True); ap.add_argument('--output-root',type=Path,required=True); ap.add_argument('--report-dir',type=Path,required=True); args=ap.parse_args()
    report=build_report(args.raw_root,args.output_root); args.report_dir.mkdir(parents=True,exist_ok=True)
    (args.report_dir/'rs-extension-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (args.report_dir/'rs-extension-validation.md').write_text(to_markdown(report),encoding='utf-8')
    print(json.dumps({'allAssertionsPassed':report['allAssertionsPassed'],'passed':sum(report['assertions'].values()),'total':len(report['assertions'])},ensure_ascii=False))
    if not report['allAssertionsPassed']:
        raise SystemExit(1)

if __name__=='__main__': main()
