#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from collections import defaultdict
from pathlib import Path
from pipeline_v2.common import read_jsonl

PIDS=['1','4','12','1409','2776','142','500','1406','3339','333','18','747','1082','4162','1675']

def grouped(path:Path):
    d=defaultdict(list)
    for r in read_jsonl(path):
        pid=str(r.get('projectId',''))
        if pid in PIDS:d[pid].append(r)
    return d

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output-root',type=Path,required=True);ap.add_argument('--year',type=int,default=2025);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    n=a.output_root/'normalized'/'rs'/f'review-{a.year}';d=a.output_root/'derived'/'rs'/f'review-{a.year}'
    blocks=grouped(n/'spending-blocks.jsonl');rels=grouped(n/'funding-relations.jsonl');ind=grouped(n/'indirect-expenses.jsonl')
    graphs={r['projectId']:r for r in read_jsonl(d/'funding-graphs.jsonl') if r.get('projectId') in PIDS}
    out={'sourceYear':a.year,'pids':{}}
    for pid in PIDS:
        out['pids'][pid]={'graph':graphs.get(pid),'spendingBlocks':blocks.get(pid,[]),'fundingRelations':rels.get(pid,[]),'indirectExpenses':ind.get(pid,[])}
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':main()
