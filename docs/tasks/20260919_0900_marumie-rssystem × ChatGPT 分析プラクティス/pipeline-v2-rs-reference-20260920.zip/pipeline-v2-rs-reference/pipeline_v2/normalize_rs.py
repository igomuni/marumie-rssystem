from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable
import csv
import hashlib
import io
import json
import re
import unicodedata
import zipfile

from .common import (
    SCHEMA_VERSION,
    canonical_project_id,
    clean_text,
    normalize_text,
    parse_bool,
    parse_int,
    parse_number,
    read_csv_file,
    relpath,
    source_ref,
    stable_id,
    write_json,
    write_jsonl,
    yen_from_thousand,
)


DATASETS: dict[str, tuple[str, str]] = {
    '1-1': ('基本情報_組織情報', 'organizations'),
    '1-2': ('基本情報_事業概要等', 'projects'),
    '1-3': ('基本情報_政策・施策、法令等', 'policies-laws'),
    '1-4': ('基本情報_補助率等', 'subsidy-rules'),
    '1-5': ('基本情報_関連事業', 'project-relations'),
    '2-1': ('予算・執行_サマリ', 'budget-summaries'),
    '2-2': ('予算・執行_予算種別・歳出予算項目', 'budget-items'),
    '3-1': ('効果発現経路_目標・実績', 'logic-model'),
    '3-2': ('効果発現経路_目標のつながり', 'logic-model-relations'),
    '4-1': ('点検・評価', 'evaluations'),
    '5-1': ('支出先_支出情報', 'spending'),
    '5-2': ('支出先_支出ブロックのつながり', 'funding-relations'),
    '5-3': ('支出先_費目・使途', 'expense-uses'),
    '5-4': ('支出先_国庫債務負担行為等による契約', 'multi-year-contracts'),
    '6-1': ('その他備考', 'notes'),
}

COMMON_COLUMNS = {
    'シート種別', '事業年度', '予算事業ID', '事業名', '府省庁の建制順',
    '政策所管府省庁', '所管府省庁', '府省庁', '局・庁', '部', '課', '室', '班', '係',
}


def _decode_csv(data: bytes) -> tuple[list[str], list[dict[str, str]]]:
    try:
        text = data.decode('utf-8-sig')
    except UnicodeDecodeError:
        text = data.decode('cp932')
    reader = csv.DictReader(io.StringIO(text))
    return list(reader.fieldnames or []), list(reader)


def _read_single_csv(zip_path: Path) -> tuple[str, list[str], list[dict[str, str]]]:
    with zipfile.ZipFile(zip_path) as zf:
        names = sorted(n for n in zf.namelist() if n.lower().endswith('.csv'))
        if not names:
            raise ValueError(f'CSV not found in {zip_path}')
        name = names[0]
        headers, rows = _decode_csv(zf.read(name))
        return name, headers, rows


def _normalized_filename(name: str) -> str:
    return unicodedata.normalize('NFKC', unicodedata.normalize('NFC', name))


def _find_zip(year_dir: Path, code: str, year: int) -> Path | None:
    if not year_dir.exists():
        return None
    prefix = f'{code}_RS_{year}_'
    candidates = sorted(
        p for p in year_dir.glob('*.zip')
        if _normalized_filename(p.name).startswith(_normalized_filename(prefix))
    )
    return candidates[0] if candidates else None


def discover_rs_years(raw_root: Path, years: set[int] | None = None) -> list[int]:
    found: set[int] = set()
    for base in [
        raw_root / 'rssystem.go.jp' / 'download-csv',
        raw_root / 'rssystem.go.jp' / 'sheets',
    ]:
        if not base.exists():
            continue
        for p in base.iterdir():
            if p.is_dir() and p.name.isdigit():
                found.add(int(p.name))
    if years:
        found &= years
    return sorted(found)


def _base(row: dict[str, str], source_year: int) -> dict[str, Any]:
    raw_id = clean_text(row.get('予算事業ID'))
    return {
        'schemaVersion': SCHEMA_VERSION,
        'sourceSystem': 'rs',
        'sourceYear': source_year,
        'reviewYear': source_year,  # compatibility alias for the previous reference implementation
        'sheetType': clean_text(row.get('シート種別')),
        'projectId': canonical_project_id(raw_id),
        'projectIdRaw': raw_id,
        'projectName': clean_text(row.get('事業名')),
        'policyMinistry': clean_text(row.get('政策所管府省庁') or row.get('所管府省庁')),
        'ministry': clean_text(row.get('府省庁')),
        'bureau': clean_text(row.get('局・庁')),
        'department': clean_text(row.get('部')),
        'division': clean_text(row.get('課')),
        'office': clean_text(row.get('室')),
        'team': clean_text(row.get('班')),
        'unit': clean_text(row.get('係')),
        'ministryOrderRaw': clean_text(row.get('府省庁の建制順') or row.get('建制順')),
    }


def _extra_fields(row: dict[str, str], mapped: set[str]) -> dict[str, str]:
    return {
        k: clean_text(v)
        for k, v in row.items()
        if k not in mapped and clean_text(v)
    }


def _source(
    raw_root: Path,
    path: Path,
    entry: str | None,
    row_number: int,
    dataset: str,
    year: int,
) -> dict[str, Any]:
    return source_ref(raw_root, path, entry, row_number, dataset=dataset, year=year)


def _record_id(raw_root: Path, path: Path, entry: str | None, row_number: int, prefix: str) -> str:
    return stable_id(relpath(path, raw_root), entry or '', row_number, prefix=prefix)


def _bool_or_raw(value: Any) -> bool | str | None:
    b = parse_bool(value)
    if b is not None:
        return b
    s = clean_text(value)
    return s or None


def _account_type(value: str) -> str:
    v = normalize_text(value)
    if v == normalize_text('一般会計'):
        return 'general'
    if v == normalize_text('特別会計'):
        return 'special'
    if v:
        return 'other'
    return ''


def _source_inventory(
    raw_root: Path,
    zip_path: Path,
    entry: str,
    headers: list[str],
    rows: list[dict[str, str]],
    mapped_columns: set[str],
    code: str,
    year: int,
) -> dict[str, Any]:
    counts = {h: 0 for h in headers}
    for row in rows:
        for h in headers:
            if clean_text(row.get(h)):
                counts[h] += 1
    mapping = []
    for h in headers:
        if h in mapped_columns:
            status = 'mapped'
        else:
            # Generic extraFields preservation means an unknown future non-empty column
            # remains visible instead of being silently discarded.
            status = 'extra_preserved' if counts[h] else 'empty_unmapped'
        mapping.append({'column': h, 'nonEmptyCount': counts[h], 'status': status})
    header_hash = hashlib.sha256(json.dumps(headers, ensure_ascii=False).encode('utf-8')).hexdigest()
    return {
        'datasetCode': code,
        'datasetName': DATASETS[code][0],
        'sourceYear': year,
        'path': relpath(zip_path, raw_root),
        'zipEntry': entry,
        'rowCount': len(rows),
        'columnCount': len(headers),
        'headerSha256': header_hash,
        'columns': mapping,
        'unknownNonEmptyColumns': [x['column'] for x in mapping if x['status'] == 'unknown_nonempty'],
    }


def normalize_organizations(raw_root: Path, path: Path, year: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    code = '1-1'; dataset = DATASETS[code][0]
    entry, headers, rows = _read_single_csv(path)
    mapped = COMMON_COLUMNS | {
        '建制順', 'その他担当組織_作成責任者_no', '府省庁（その他担当組織）',
        '局・庁（その他担当組織）', '部（その他担当組織）', '課（その他担当組織）',
        '室（その他担当組織）', '班（その他担当組織）', '係（その他担当組織）', '作成責任者',
    }
    out = []
    for row_number, row in enumerate(rows, start=2):
        rec = _base(row, year)
        rec.update({
            'recordType': 'rs_organization_relation',
            'recordId': _record_id(raw_root, path, entry, row_number, 'rsorg_'),
            'additionalOrganizationNo': clean_text(row.get('その他担当組織_作成責任者_no')),
            'additionalMinistry': clean_text(row.get('府省庁（その他担当組織）')),
            'additionalBureau': clean_text(row.get('局・庁（その他担当組織）')),
            'additionalDepartment': clean_text(row.get('部（その他担当組織）')),
            'additionalDivision': clean_text(row.get('課（その他担当組織）')),
            'additionalOffice': clean_text(row.get('室（その他担当組織）')),
            'additionalTeam': clean_text(row.get('班（その他担当組織）')),
            'additionalUnit': clean_text(row.get('係（その他担当組織）')),
            'responsiblePerson': clean_text(row.get('作成責任者')),
            'extraFields': _extra_fields(row, mapped),
            'source': _source(raw_root, path, entry, row_number, dataset, year),
        })
        out.append(rec)
    return out, _source_inventory(raw_root, path, entry, headers, rows, mapped, code, year)


def normalize_project_rows(raw_root: Path, path: Path, year: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    code = '1-2'; dataset = DATASETS[code][0]
    entry, headers, rows = _read_single_csv(path)
    mapped = COMMON_COLUMNS | {
        '事業の目的', '現状・課題', '事業の概要', '事業概要URL', '事業区分', '事業開始年度',
        '開始年度不明', '事業終了（予定）年度', '終了予定なし', '主要経費', '備考',
        '実施方法ー直接実施', '実施方法ー補助', '実施方法ー負担', '実施方法ー交付',
        '実施方法ー分担金・拠出金', '実施方法ーその他', '旧事業番号', '整理表表示順',
    }
    out = []
    for row_number, row in enumerate(rows, start=2):
        rec = _base(row, year)
        rec.update({
            'recordType': 'rs_project_source_row',
            'recordId': _record_id(raw_root, path, entry, row_number, 'rsproj_'),
            'purpose': clean_text(row.get('事業の目的')),
            'currentIssues': clean_text(row.get('現状・課題')),
            'overview': clean_text(row.get('事業の概要')),
            'overviewUrl': clean_text(row.get('事業概要URL')),
            'projectCategory': clean_text(row.get('事業区分')),
            'startYear': parse_int(row.get('事業開始年度'), none_if_blank=True),
            'startYearUnknown': parse_bool(row.get('開始年度不明')),
            'endYear': parse_int(row.get('事業終了（予定）年度'), none_if_blank=True),
            'endYearRaw': clean_text(row.get('事業終了（予定）年度')),
            'noPlannedEnd': parse_bool(row.get('終了予定なし')),
            'majorExpense': clean_text(row.get('主要経費')),
            'note': clean_text(row.get('備考')),
            'implementationMethods': {
                'direct': _bool_or_raw(row.get('実施方法ー直接実施')),
                'subsidy': _bool_or_raw(row.get('実施方法ー補助')),
                'burden': _bool_or_raw(row.get('実施方法ー負担')),
                'grant': _bool_or_raw(row.get('実施方法ー交付')),
                'contribution': _bool_or_raw(row.get('実施方法ー分担金・拠出金')),
                'other': clean_text(row.get('実施方法ーその他')) or None,
            },
            'legacyProjectNumber': clean_text(row.get('旧事業番号')),
            'displayOrderRaw': clean_text(row.get('整理表表示順')),
            'extraFields': _extra_fields(row, mapped),
            'source': _source(raw_root, path, entry, row_number, dataset, year),
        })
        out.append(rec)
    return out, _source_inventory(raw_root, path, entry, headers, rows, mapped, code, year)


def normalize_policies_laws(raw_root: Path, path: Path, year: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    code='1-3'; dataset=DATASETS[code][0]
    entry, headers, rows = _read_single_csv(path)
    mapped = COMMON_COLUMNS | {
        '番号（政策・施策）', '政策所管府省庁_P', '政策', '施策', '政策・施策URL',
        '番号（根拠法令）', '法令名', '法令番号', '法令ID', '条', '項', '号・号の細分',
        '番号（関係する計画・通知等）', '計画通知名', '計画通知等URL',
    }
    out=[]
    for row_number,row in enumerate(rows,start=2):
        rec=_base(row,year)
        rec.update({
            'recordType':'rs_policy_law_relation',
            'recordId':_record_id(raw_root,path,entry,row_number,'rspol_'),
            'policyMeasureNo':clean_text(row.get('番号（政策・施策）')),
            'policyOwnerMinistry':clean_text(row.get('政策所管府省庁_P')),
            'policy':clean_text(row.get('政策')),
            'measure':clean_text(row.get('施策')),
            'policyMeasureUrl':clean_text(row.get('政策・施策URL')),
            'lawNo':clean_text(row.get('番号（根拠法令）')),
            'lawName':clean_text(row.get('法令名')),
            'lawNumber':clean_text(row.get('法令番号')),
            'lawId':clean_text(row.get('法令ID')),
            'article':clean_text(row.get('条')),
            'paragraph':clean_text(row.get('項')),
            'item':clean_text(row.get('号・号の細分')),
            'planNo':clean_text(row.get('番号（関係する計画・通知等）')),
            'planName':clean_text(row.get('計画通知名')),
            'planUrl':clean_text(row.get('計画通知等URL')),
            'extraFields':_extra_fields(row,mapped),
            'source':_source(raw_root,path,entry,row_number,dataset,year),
        })
        out.append(rec)
    return out,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


def normalize_subsidy_rules(raw_root: Path, path: Path, year: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    code='1-4'; dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path)
    mapped=COMMON_COLUMNS|{'番号（補助率等）','補助対象','補助率','補助上限等','補助率URL'}
    out=[]
    for row_number,row in enumerate(rows,start=2):
        rec=_base(row,year)
        has_rule=any(clean_text(row.get(c)) for c in ['補助対象','補助率','補助上限等','補助率URL'])
        rec.update({
            'recordType':'rs_subsidy_rule','recordId':_record_id(raw_root,path,entry,row_number,'rssub_'),
            'ruleNo':clean_text(row.get('番号（補助率等）')),'target':clean_text(row.get('補助対象')),
            'rateRaw':clean_text(row.get('補助率')),'upperLimitRaw':clean_text(row.get('補助上限等')),
            'url':clean_text(row.get('補助率URL')),'hasRule':has_rule,'extraFields':_extra_fields(row,mapped),
            'source':_source(raw_root,path,entry,row_number,dataset,year),
        });out.append(rec)
    return out,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


def normalize_project_relations(raw_root: Path, path: Path, year: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    code='1-5';dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path)
    mapped=COMMON_COLUMNS|{'番号（関連事業）','関連事業の事業ID','関連事業の事業名','関連性'}
    out=[]
    for row_number,row in enumerate(rows,start=2):
        rec=_base(row,year);ridraw=clean_text(row.get('関連事業の事業ID'))
        rec.update({
            'recordType':'rs_project_relation','recordId':_record_id(raw_root,path,entry,row_number,'rsprrel_'),
            'relationNo':clean_text(row.get('番号（関連事業）')),'relatedProjectId':canonical_project_id(ridraw),
            'relatedProjectIdRaw':ridraw,'relatedProjectName':clean_text(row.get('関連事業の事業名')),
            'relationTypeRaw':clean_text(row.get('関連性')),
            'hasRelation':bool(ridraw or clean_text(row.get('関連事業の事業名')) or clean_text(row.get('関連性'))),
            'extraFields':_extra_fields(row,mapped),'source':_source(raw_root,path,entry,row_number,dataset,year),
        });out.append(rec)
    return out,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


PROJECT_TOTAL_AMOUNT_COLUMNS = {
    '当初予算（合計）': ('initial', 0),
    '補正予算（合計）': ('supplementary', None),
    '前年度からの繰越し（合計）': ('carryover_in', None),
    '予備費等（合計）': ('adjustment', None),
    '計（歳出予算現額合計）': ('current_budget', None),
    '執行額（合計）': ('execution', None),
    '翌年度への繰越し(合計）': ('carryover_out', None),
    '翌年度要求額（合計）': ('request', None),
}
ACCOUNT_AMOUNT_COLUMNS = {
    '当初予算': ('initial', 0),
    '第1次補正予算': ('supplementary', 1),
    '第2次補正予算': ('supplementary', 2),
    '第3次補正予算': ('supplementary', 3),
    '第4次補正予算': ('supplementary', 4),
    '第5次補正予算': ('supplementary', 5),
    '前年度から繰越し': ('carryover_in', None),
    '予備費等1': ('adjustment', 1),
    '予備費等2': ('adjustment', 2),
    '予備費等3': ('adjustment', 3),
    '予備費等4': ('adjustment', 4),
    '歳出予算現額': ('current_budget', None),
    '執行額': ('execution', None),
    '翌年度要求額': ('request', None),
    '要望額': ('request_preference', None),
}


def normalize_budget_summary(raw_root: Path, path: Path, year: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    code='2-1';dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path)
    mapped=COMMON_COLUMNS|{
        '予算年度','執行率','主な増減理由','その他特記事項','会計区分','会計','勘定','備考',
        *PROJECT_TOTAL_AMOUNT_COLUMNS.keys(),*ACCOUNT_AMOUNT_COLUMNS.keys(),
    }
    summaries=[];events=[]
    for row_number,row in enumerate(rows,start=2):
        base=_base(row,year);fy=parse_int(row.get('予算年度'),none_if_blank=True);ac=clean_text(row.get('会計区分'))
        scope='account' if ac else 'project_total'
        rec=dict(base)
        rec.update({
            'recordType':'rs_budget_summary','recordId':_record_id(raw_root,path,entry,row_number,'rssum_'),
            'fiscalYear':fy,'scopeLevel':scope,'accountType':_account_type(ac),'accountClass':ac,
            'account':clean_text(row.get('会計')),'subAccount':clean_text(row.get('勘定')),
            'executionRateRaw':clean_text(row.get('執行率')),'changeReason':clean_text(row.get('主な増減理由')),
            'specialNotes':clean_text(row.get('その他特記事項')),'note':clean_text(row.get('備考')),
            'amounts':{c:parse_number(row.get(c)) for c in [*PROJECT_TOTAL_AMOUNT_COLUMNS,*ACCOUNT_AMOUNT_COLUMNS]},
            'amountsRaw':{c:clean_text(row.get(c)) for c in [*PROJECT_TOTAL_AMOUNT_COLUMNS,*ACCOUNT_AMOUNT_COLUMNS] if clean_text(row.get(c))},
            'extraFields':_extra_fields(row,mapped),'source':_source(raw_root,path,entry,row_number,dataset,year),
        });summaries.append(rec)
        cols=PROJECT_TOTAL_AMOUNT_COLUMNS if scope=='project_total' else ACCOUNT_AMOUNT_COLUMNS
        for col,(event_type,revision) in cols.items():
            raw=clean_text(row.get(col))
            if not raw:
                continue
            amount=parse_number(raw)
            if amount is None:
                continue
            event_fy = fy + 1 if fy is not None and event_type in {'request','request_preference'} else fy
            evt=dict(base)
            evt.update({
                'recordType':'rs_budget_event','eventId':stable_id(rec['recordId'],col,prefix='rsevt_'),
                'sourceRecordId':rec['recordId'],'fiscalYear':event_fy,'sourceFiscalYear':fy,
                'eventType':event_type,'revision':revision,'amountYen':amount,'amountRaw':raw,
                'sourceAmountColumn':col,'scopeLevel':scope,'accountType':_account_type(ac),'accountClass':ac,
                'account':clean_text(row.get('会計')),'subAccount':clean_text(row.get('勘定')),
                'semanticStatus':'source_neutral' if event_type=='adjustment' else 'source_labeled',
                'source':rec['source'],
            });events.append(evt)
    inv=_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)
    return summaries,events,inv


def normalize_budget_items(raw_root: Path, path: Path, year: int) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    code='2-2';dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path)
    mapped=COMMON_COLUMNS|{'予算年度','会計区分','会計','勘定','予算種別','所管','組織・勘定','項','目','歳出予算項目の補足情報','予算額（歳出予算項目ごと）','翌年度要求額（歳出予算項目ごと）','備考（歳出予算項目ごと）'}
    out=[]
    for row_number,row in enumerate(rows,start=2):
        rec=_base(row,year);fy=parse_int(row.get('予算年度'),none_if_blank=True);ac=clean_text(row.get('会計区分'))
        ministry=clean_text(row.get('所管'));orgacc=clean_text(row.get('組織・勘定'));section=clean_text(row.get('項'));item=clean_text(row.get('目'))
        amount_raw=clean_text(row.get('予算額（歳出予算項目ごと）'));request_raw=clean_text(row.get('翌年度要求額（歳出予算項目ごと）'))
        rec.update({
            'recordType':'rs_budget_item','recordId':_record_id(raw_root,path,entry,row_number,'rsitem_'),
            'fiscalYear':fy,'accountType':_account_type(ac),'accountClass':ac,'account':clean_text(row.get('会計')),
            'subAccount':clean_text(row.get('勘定')),'budgetType':clean_text(row.get('予算種別')),'ministry':ministry,
            'organizationOrAccount':orgacc,'sectionName':section,'subItemName':item,'supplementalInfo':clean_text(row.get('歳出予算項目の補足情報')),
            'budgetAmountYen':parse_number(amount_raw),'budgetAmountRaw':amount_raw,'nextYearRequestYen':parse_number(request_raw),
            'nextYearRequestRaw':request_raw,'requestFiscalYear':fy+1 if fy is not None and request_raw else None,
            'note':clean_text(row.get('備考（歳出予算項目ごと）')),
            'mofNameNaturalKey':'|'.join(normalize_text(x) for x in [_account_type(ac),ministry,orgacc,section,item]),
            'extraFields':_extra_fields(row,mapped),'source':_source(raw_root,path,entry,row_number,dataset,year),
        });out.append(rec)
    return out,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


def _logic_value_type(raw: str) -> str:
    s=normalize_text(raw)
    if '目標年度' in s: return 'target_year'
    if '目標値' in s: return 'target'
    if '実績値' in s: return 'actual'
    if '達成率' in s: return 'achievement_rate'
    return 'other'


def normalize_logic_model(raw_root: Path, path: Path, year: int) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    code='3-1';dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path)
    year_cols={h for h in headers if re.fullmatch(r'20\d{2}',h)}
    mapped=COMMON_COLUMNS|{
        '事業に関連するKPIが定められている閣議決定等の名称','事業に関連するKPIが定められている閣議決定等の該当箇所','事業に関連するKPIが定められている閣議決定等のURL',
        'アクティビティ・アウトプット・アウトカムの番号','種別（アクティビティ・アウトプット・アウトカム）','アウトカムの期間','成果目標の種類','アクティビティ／活動目標／成果目標','活動指標／成果指標','単位','改善の上向き／下向き','成果実績及び目標値の根拠として用いた統計・データ名（出典）','定性的なアウトカム目標を設定している理由','定性的なアウトカムに関する成果実績','目標年度／目標値／実績値／達成率',
    }|year_cols
    node_build:dict[tuple[str,str],dict[str,Any]]={};observations=[]
    for row_number,row in enumerate(rows,start=2):
        base=_base(row,year);num=clean_text(row.get('アクティビティ・アウトプット・アウトカムの番号'));kind=clean_text(row.get('種別（アクティビティ・アウトプット・アウトカム）'))
        # Number is source-defined within a project and is the cleanest stable node reference for 3-2.
        node_id=stable_id(year,base['projectId'],num,kind,prefix='rslogic_')
        src=_source(raw_root,path,entry,row_number,dataset,year);evidence_id=_record_id(raw_root,path,entry,row_number,'rslogicrow_')
        key=(base['projectId'],node_id)
        if key not in node_build:
            node=dict(base)
            node.update({
                'recordType':'rs_logic_node','logicNodeId':node_id,'nodeNumber':num,'nodeTypeRaw':kind,
                'outcomePeriod':clean_text(row.get('アウトカムの期間')),'goalType':clean_text(row.get('成果目標の種類')),
                'goal':clean_text(row.get('アクティビティ／活動目標／成果目標')),'indicator':clean_text(row.get('活動指標／成果指標')),
                'unit':clean_text(row.get('単位')),'direction':clean_text(row.get('改善の上向き／下向き')),
                'statisticsSource':clean_text(row.get('成果実績及び目標値の根拠として用いた統計・データ名（出典）')),
                'qualitativeReason':clean_text(row.get('定性的なアウトカム目標を設定している理由')),
                'qualitativeResult':clean_text(row.get('定性的なアウトカムに関する成果実績')),
                'kpiDecisionName':clean_text(row.get('事業に関連するKPIが定められている閣議決定等の名称')),
                'kpiDecisionSection':clean_text(row.get('事業に関連するKPIが定められている閣議決定等の該当箇所')),
                'kpiDecisionUrl':clean_text(row.get('事業に関連するKPIが定められている閣議決定等のURL')),
                'evidenceRowIds':[],'sources':[],'extraFields':{},
            });node_build[key]=node
        node=node_build[key];node['evidenceRowIds'].append(evidence_id);node['sources'].append(src)
        # Preserve extra fields if future columns appear. Conflicting values are arrays.
        for k,v in _extra_fields(row,mapped).items():
            old=node['extraFields'].get(k)
            if old is None: node['extraFields'][k]=v
            elif old!=v:
                vals=old if isinstance(old,list) else [old]
                if v not in vals: vals.append(v)
                node['extraFields'][k]=vals
        value_type_raw=clean_text(row.get('目標年度／目標値／実績値／達成率'));value_type=_logic_value_type(value_type_raw)
        for yc in sorted(year_cols):
            raw=clean_text(row.get(yc))
            if not raw: continue
            observations.append({
                'schemaVersion':SCHEMA_VERSION,'recordType':'rs_logic_observation',
                'observationId':stable_id(evidence_id,yc,prefix='rsobs_'),'sourceYear':year,'reviewYear':year,
                'projectId':base['projectId'],'projectIdRaw':base['projectIdRaw'],'logicNodeId':node_id,
                'fiscalYear':int(yc),'valueType':value_type,'valueTypeRaw':value_type_raw,'valueRaw':raw,
                'valueNumber':parse_number(raw),'unit':node.get('unit',''),'sourceRowId':evidence_id,'source':src,
            })
    return list(node_build.values()),observations,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


def normalize_logic_relations(raw_root: Path,path: Path,year: int) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    code='3-2';dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path)
    mapped=COMMON_COLUMNS|{
        '派生元ーアクティビティ・アウトプット・アウトカムの番号','派生元ー種別（アクティビティ・アウトプット・アウトカム）','派生元ーアウトカムの期間','派生元ーアクティビティの内容/ 活動目標／成果目標','派生元ー活動指標／成果指標',
        '派生先ーアクティビティ・アウトプット・アウトカムの番号','派生先ー種別（アクティビティ・アウトプット・アウトカム）','派生先ーアウトカムの期間','派生先ー 活動目標／成果目標','派生先ー活動指標／成果指標','後続アウトカムへのつながり','アウトカムを複数段階で設定できない理由',
    }
    out=[]
    for row_number,row in enumerate(rows,start=2):
        base=_base(row,year);sn=clean_text(row.get('派生元ーアクティビティ・アウトプット・アウトカムの番号'));sk=clean_text(row.get('派生元ー種別（アクティビティ・アウトプット・アウトカム）'));tn=clean_text(row.get('派生先ーアクティビティ・アウトプット・アウトカムの番号'));tk=clean_text(row.get('派生先ー種別（アクティビティ・アウトプット・アウトカム）'))
        rec=dict(base);rec.update({
            'recordType':'rs_logic_relation','relationId':_record_id(raw_root,path,entry,row_number,'rslogicrel_'),
            'sourceNodeNumber':sn,'sourceNodeTypeRaw':sk,'sourceLogicNodeId':stable_id(year,base['projectId'],sn,sk,prefix='rslogic_') if sn else '',
            'sourceOutcomePeriod':clean_text(row.get('派生元ーアウトカムの期間')),'sourceGoal':clean_text(row.get('派生元ーアクティビティの内容/ 活動目標／成果目標')),'sourceIndicator':clean_text(row.get('派生元ー活動指標／成果指標')),
            'targetNodeNumber':tn,'targetNodeTypeRaw':tk,'targetLogicNodeId':stable_id(year,base['projectId'],tn,tk,prefix='rslogic_') if tn else '',
            'targetOutcomePeriod':clean_text(row.get('派生先ーアウトカムの期間')),'targetGoal':clean_text(row.get('派生先ー 活動目標／成果目標')),'targetIndicator':clean_text(row.get('派生先ー活動指標／成果指標')),
            'connectionToLaterOutcome':clean_text(row.get('後続アウトカムへのつながり')),'reasonNoMultipleOutcomeStages':clean_text(row.get('アウトカムを複数段階で設定できない理由')),
            'hasRelation':bool(sn and tn),'extraFields':_extra_fields(row,mapped),'source':_source(raw_root,path,entry,row_number,dataset,year),
        });out.append(rec)
    return out,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


def normalize_evaluations(raw_root: Path,path: Path,year: int) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    code='4-1';dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path)
    fields={
        '事業所管部局による点検・改善ー点検結果':'departmentCheckResult','事業所管部局による点検・改善ー改善の方向性':'departmentImprovementDirection','事業所管部局による点検・改善－目標年度における効果測定に関する評価':'targetYearEffectEvaluation',
        '外部有識者による点検ー最終実施年度':'externalReviewLatestYear','外部有識者による点検ー点検対象':'externalReviewTarget','外部有識者による点検ー対象の理由':'externalReviewReason','外部有識者による点検ー所見':'externalReviewFindings',
        '公開プロセス結果概要':'publicProcessSummary','行政事業レビュー推進チームの所見':'reviewTeamFinding','行政事業レビュー推進チームの所見の詳細':'reviewTeamFindingDetail','所見を踏まえた改善点／概算要求における反映状況':'requestReflectionStatus','所見を踏まえた改善点／概算要求における反映状況の詳細':'requestReflectionDetail',
        '反映額（一般会計）':'reflectionGeneralRaw','反映額（特別会計）－会計':'reflectionSpecialAccount','反映額（特別会計）－勘定':'reflectionSpecialSubAccount','反映額（特別会計）－反映額':'reflectionSpecialRaw',
        '過去に受けた指摘事項－区分':'pastFindingCategory','過去に受けた指摘事項－取りまとめ年度':'pastFindingYear','過去に受けた指摘事項－取りまとめ内容':'pastFinding','過去に受けた指摘事項－対応状況':'pastFindingResponse',
        'その他の指摘事項－調査等の名称':'otherFindingSource','その他の指摘事項－指摘年度':'otherFindingYear','その他の指摘事項－指摘内容':'otherFinding','その他の指摘事項－対応状況':'otherFindingResponse',
    }
    mapped=COMMON_COLUMNS|set(fields)
    out=[]
    for row_number,row in enumerate(rows,start=2):
        rec=_base(row,year);rec.update({'recordType':'rs_evaluation','recordId':_record_id(raw_root,path,entry,row_number,'rseval_')})
        for src,dst in fields.items(): rec[dst]=clean_text(row.get(src))
        rec['reflectionGeneralYen']=parse_number(row.get('反映額（一般会計）'));rec['reflectionSpecialYen']=parse_number(row.get('反映額（特別会計）－反映額'))
        rec['extraFields']=_extra_fields(row,mapped);rec['source']=_source(raw_root,path,entry,row_number,dataset,year);out.append(rec)
    return out,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


def normalize_spending(raw_root: Path,path: Path,year: int) -> tuple[list[dict[str,Any]],list[dict[str,Any]],list[dict[str,Any]],dict[str,Any]]:
    code='5-1';dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path)
    mapped=COMMON_COLUMNS|{'支出先ブロック番号','支出先ブロック名','支出先の数','事業を行う上での役割','ブロックの合計支出額','支出先名','法人番号','所在地','法人種別','その他支出先','支出先の合計支出額','契約概要','金額','契約方式等','具体的な契約方式等','入札者数','落札率','一者応札・一者応募又は競争性のない随意契約となった理由及び改善策（支出額10億円以上）','その他の契約'}
    blocks:dict[tuple[str,str],dict[str,Any]]={};recipients:dict[tuple[str,str,str,str,str,str,str],dict[str,Any]]={};contracts=[]
    last_recipient_by_block:dict[tuple[str,str],str]={}
    for row_number,row in enumerate(rows,start=2):
        base=_base(row,year);pid=base['projectId'];bid=clean_text(row.get('支出先ブロック番号'));src=_source(raw_root,path,entry,row_number,dataset,year);row_id=_record_id(raw_root,path,entry,row_number,'rsspendrow_')
        bkey=(pid,bid)
        summary_present=any(clean_text(row.get(c)) for c in ['支出先ブロック名','支出先の数','事業を行う上での役割','ブロックの合計支出額'])
        if bid and (bkey not in blocks):
            brec=dict(base);brec.update({'recordType':'rs_spending_block','nodeId':f'project:{pid}:block:{bid}','blockId':bid,'blockName':'','blockNames':[],'recipientCountValues':[],'roles':[],'totalAmountValuesYen':[],'evidenceRowIds':[],'sources':[],'summaryRowCount':0,'extraFields':{}});blocks[bkey]=brec
        if bid and summary_present:
            b=blocks[bkey];b['summaryRowCount']+=1;b['evidenceRowIds'].append(row_id);b['sources'].append(src)
            name=clean_text(row.get('支出先ブロック名'));role=clean_text(row.get('事業を行う上での役割'));cnt=parse_int(row.get('支出先の数'),none_if_blank=True);amt=parse_number(row.get('ブロックの合計支出額'))
            if name and name not in b['blockNames']: b['blockNames'].append(name)
            if not b['blockName'] and name: b['blockName']=name
            if role and role not in b['roles']: b['roles'].append(role)
            if cnt is not None and cnt not in b['recipientCountValues']: b['recipientCountValues'].append(cnt)
            if amt is not None and amt not in b['totalAmountValuesYen']: b['totalAmountValuesYen'].append(amt)
            for k,v in _extra_fields(row,mapped).items(): b['extraFields'].setdefault(k,[]); b['extraFields'][k] = sorted(set(b['extraFields'][k]+[v]))
        rname=clean_text(row.get('支出先名'));corp=clean_text(row.get('法人番号'));loc=clean_text(row.get('所在地'));ctype=clean_text(row.get('法人種別'));other=clean_text(row.get('その他支出先'))
        recipient_id=''
        if bid and any([rname,corp,loc,ctype,other,clean_text(row.get('支出先の合計支出額'))]):
            rkey=(pid,bid,rname,corp,loc,ctype,other)
            if rkey not in recipients:
                recipient_id=stable_id(year,*rkey,prefix='rsrecipient_');rrec=dict(base);rrec.update({'recordType':'rs_recipient','recipientId':recipient_id,'blockId':bid,'recipientName':rname,'corporateNumber':corp,'location':loc,'corporateType':ctype,'otherRecipient':parse_bool(other),'totalAmountValuesYen':[],'evidenceRowIds':[],'sources':[],'extraFields':{}});recipients[rkey]=rrec
            rrec=recipients[rkey];recipient_id=rrec['recipientId'];rrec['evidenceRowIds'].append(row_id);rrec['sources'].append(src);tamt=parse_number(row.get('支出先の合計支出額'))
            if tamt is not None and tamt not in rrec['totalAmountValuesYen']: rrec['totalAmountValuesYen'].append(tamt)
            last_recipient_by_block[bkey]=recipient_id
        contract_cols=['契約概要','金額','契約方式等','具体的な契約方式等','入札者数','落札率','一者応札・一者応募又は競争性のない随意契約となった理由及び改善策（支出額10億円以上）','その他の契約']
        if bid and any(clean_text(row.get(c)) for c in contract_cols):
            if not recipient_id: recipient_id=last_recipient_by_block.get(bkey,'')
            crec=dict(base);crec.update({
                'recordType':'rs_contract','contractId':stable_id(row_id,'contract',prefix='rscontract_'),'blockId':bid,'recipientId':recipient_id or None,
                'recipientLinkMethod':'same-row' if rname else ('preceding-row' if recipient_id else None),'recipientNameRaw':rname,'corporateNumberRaw':corp,
                'summary':clean_text(row.get('契約概要')),'amountYen':parse_number(row.get('金額')),'amountRaw':clean_text(row.get('金額')),
                'method':clean_text(row.get('契約方式等')),'methodDetail':clean_text(row.get('具体的な契約方式等')),
                'bidderCount':parse_int(row.get('入札者数'),none_if_blank=True),'winningRate':parse_number(row.get('落札率')),
                'singleBidReason':clean_text(row.get('一者応札・一者応募又は競争性のない随意契約となった理由及び改善策（支出額10億円以上）')),
                'otherContract':parse_bool(row.get('その他の契約')),'sourceRowId':row_id,'source':src,'extraFields':_extra_fields(row,mapped),
            });contracts.append(crec)
    return list(blocks.values()),list(recipients.values()),contracts,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


def normalize_funding_relations(raw_root: Path,path: Path,year: int) -> tuple[list[dict[str,Any]],list[dict[str,Any]],dict[str,Any]]:
    code='5-2';dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path)
    mapped=COMMON_COLUMNS|{'支出元の支出先ブロック','支出元の支出先ブロック名','担当組織からの支出','支出先の支出先ブロック','支出先の支出先ブロック名','資金の流れの補足情報','国自らが支出する間接経費','国自らが支出する間接経費の項目','国自らが支出する間接経費の金額'}
    relations=[];indirect=[]
    for row_number,row in enumerate(rows,start=2):
        base=_base(row,year);src=_source(raw_root,path,entry,row_number,dataset,year);row_id=_record_id(raw_root,path,entry,row_number,'rsflowrow_')
        sbid=clean_text(row.get('支出元の支出先ブロック'));sname=clean_text(row.get('支出元の支出先ブロック名'));tbid=clean_text(row.get('支出先の支出先ブロック'));tname=clean_text(row.get('支出先の支出先ブロック名'));from_org=parse_bool(row.get('担当組織からの支出'))
        if tbid or tname:
            rec=dict(base);rec.update({
                'recordType':'rs_funding_relation','relationId':stable_id(row_id,'relation',prefix='rsfundrel_'),'sourceBlockId':sbid or None,'sourceBlockName':sname,
                'fromResponsibleOrganization':from_org,'targetBlockId':tbid,'targetBlockName':tname,'note':clean_text(row.get('資金の流れの補足情報')),
                'sourceRowId':row_id,'extraFields':_extra_fields(row,mapped),'source':src,
            });relations.append(rec)
        cat=clean_text(row.get('国自らが支出する間接経費'));item=clean_text(row.get('国自らが支出する間接経費の項目'));amount_raw=clean_text(row.get('国自らが支出する間接経費の金額'))
        if cat or item or amount_raw:
            rec=dict(base);rec.update({'recordType':'rs_indirect_expense','expenseId':stable_id(row_id,'indirect',prefix='rsindirect_'),'categoryRaw':cat,'item':item,'amountYen':parse_number(amount_raw),'amountRaw':amount_raw,'sourceRowId':row_id,'extraFields':_extra_fields(row,mapped),'source':src});indirect.append(rec)
    return relations,indirect,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


def normalize_expense_uses(raw_root: Path,path: Path,year: int) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    code='5-3';dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path)
    mapped=COMMON_COLUMNS|{'支出先ブロック番号','支出先名','法人番号','契約概要','費目','使途','金額'}
    out=[]
    for row_number,row in enumerate(rows,start=2):
        base=_base(row,year);rec=dict(base);raw=clean_text(row.get('金額'))
        rec.update({'recordType':'rs_expense_use','expenseUseId':_record_id(raw_root,path,entry,row_number,'rsuse_'),'blockId':clean_text(row.get('支出先ブロック番号')),'recipientName':clean_text(row.get('支出先名')),'corporateNumber':clean_text(row.get('法人番号')),'contractSummary':clean_text(row.get('契約概要')),'expenseItem':clean_text(row.get('費目')),'use':clean_text(row.get('使途')),'amountYen':parse_number(raw),'amountRaw':raw,'extraFields':_extra_fields(row,mapped),'source':_source(raw_root,path,entry,row_number,dataset,year)});out.append(rec)
    return out,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


def normalize_multi_year_contracts(raw_root: Path,path: Path,year: int) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    code='5-4';dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path)
    mapped=COMMON_COLUMNS|{'支出先ブロック（国庫債務負担行為等による契約）','契約先名（国庫債務負担行為等による契約）','契約先の法人番号（国庫債務負担行為等による契約）','契約先の所在地（国庫債務負担行為等による契約）','契約先の法人種別（国庫債務負担行為等による契約）','契約概要（契約名）（国庫債務負担行為等による契約）','その他の契約','契約額（国庫債務負担行為等による契約）','契約方式等（国庫債務負担行為等による契約）','具体的な契約方式等（国庫債務負担行為等による契約）','入札者数（応募者数）（国庫債務負担行為等による契約）','落札率（％）（国庫債務負担行為等による契約）','一者応札・一者応募又は競争性のない随意契約となった理由及び改善策（契約額10億円以上）（国庫債務負担行為等による契約）','その他の契約（国庫債務負担行為等による契約）'}
    out=[]
    for row_number,row in enumerate(rows,start=2):
        base=_base(row,year);amount_raw=clean_text(row.get('契約額（国庫債務負担行為等による契約）'));rec=dict(base)
        rec.update({'recordType':'rs_multi_year_contract','contractId':_record_id(raw_root,path,entry,row_number,'rsmulti_'),'blockId':clean_text(row.get('支出先ブロック（国庫債務負担行為等による契約）')),'recipientName':clean_text(row.get('契約先名（国庫債務負担行為等による契約）')),'corporateNumber':clean_text(row.get('契約先の法人番号（国庫債務負担行為等による契約）')),'location':clean_text(row.get('契約先の所在地（国庫債務負担行為等による契約）')),'corporateType':clean_text(row.get('契約先の法人種別（国庫債務負担行為等による契約）')),'summary':clean_text(row.get('契約概要（契約名）（国庫債務負担行為等による契約）')),'amountYen':parse_number(amount_raw),'amountRaw':amount_raw,'method':clean_text(row.get('契約方式等（国庫債務負担行為等による契約）')),'methodDetail':clean_text(row.get('具体的な契約方式等（国庫債務負担行為等による契約）')),'bidderCount':parse_int(row.get('入札者数（応募者数）（国庫債務負担行為等による契約）'),none_if_blank=True),'winningRate':parse_number(row.get('落札率（％）（国庫債務負担行為等による契約）')),'singleBidReason':clean_text(row.get('一者応札・一者応募又は競争性のない随意契約となった理由及び改善策（契約額10億円以上）（国庫債務負担行為等による契約）')),'otherContractRaw':clean_text(row.get('その他の契約（国庫債務負担行為等による契約）') or row.get('その他の契約')),'hasContract':bool(amount_raw or clean_text(row.get('契約先名（国庫債務負担行為等による契約）')) or clean_text(row.get('契約概要（契約名）（国庫債務負担行為等による契約）'))),'extraFields':_extra_fields(row,mapped),'source':_source(raw_root,path,entry,row_number,dataset,year)});out.append(rec)
    return out,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


def normalize_notes(raw_root: Path,path: Path,year: int) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    code='6-1';dataset=DATASETS[code][0]
    entry,headers,rows=_read_single_csv(path);mapped=COMMON_COLUMNS|{'備考'};out=[]
    for row_number,row in enumerate(rows,start=2):
        base=_base(row,year);rec=dict(base);rec.update({'recordType':'rs_project_note','noteId':_record_id(raw_root,path,entry,row_number,'rsnote_'),'note':clean_text(row.get('備考')),'extraFields':_extra_fields(row,mapped),'source':_source(raw_root,path,entry,row_number,dataset,year)});out.append(rec)
    return out,_source_inventory(raw_root,path,entry,headers,rows,mapped,code,year)


def _sheet_form(path: Path) -> str | None:
    n=_normalized_filename(path.name)
    if '(様式1)' in n: return 'form1'
    if '(様式2)' in n: return 'form2'
    return None


def _sheet_ministry(path: Path, year: int) -> str:
    token=f'_{year}年度_'
    name=path.name
    return clean_text(name.split(token)[0]) if token in name else ''


def normalize_review_sheets(raw_root: Path, year: int) -> tuple[list[dict[str,Any]],dict[str,Any]]:
    base_dir=raw_root/'rssystem.go.jp'/'sheets'/str(year);out=[];files=[];ignored=[]
    if not base_dir.exists(): return [],{'sourceYear':year,'available':False,'files':[],'ignoredFiles':[],'rowCount':0}
    for path in sorted(base_dir.rglob('*.csv')):
        form=_sheet_form(path)
        if not form:
            ignored.append({'path':relpath(path,raw_root),'reason':'outside current normalized sheets scope (only form1/form2 are specified)'})
            continue
        headers,rows=read_csv_file(path);files.append({'path':relpath(path,raw_root),'form':form,'rowCount':len(rows),'headers':headers})
        ministry=_sheet_ministry(path,year)
        for row_number,row in enumerate(rows,start=2):
            raw_id=clean_text(row.get('予算事業ID'));pid=canonical_project_id(raw_id);src=_source(raw_root,path,None,row_number,f'sheets-{form}',year)
            rec={'schemaVersion':SCHEMA_VERSION,'recordType':'rs_review_sheet','sheetForm':form,'sourceYear':year,'reviewYear':year,'projectId':pid,'projectIdRaw':raw_id,'projectName':clean_text(row.get('事業名')),'ministryFromFile':ministry,'policy':clean_text(row.get('政策')),'measure':clean_text(row.get('施策')),'responsibleOffice':clean_text(row.get('事業所管課室')),'accountClass':clean_text(row.get('会計区分')),'officialProjectUrl':clean_text(row.get('事業URL')),'reviewTeamFinding':clean_text(row.get('行政事業レビュー推進チームの所見')),'source':src}
            if form=='form1':
                prior=year-1;nexty=year+1
                rec.update({'projectCategory':'existing_or_new_start','startYear':parse_int(row.get('事業開始年度'),none_if_blank=True),'startYearRaw':clean_text(row.get('事業開始年度')),'endYear':parse_int(row.get('事業終了（予定）年度'),none_if_blank=True),'endYearRaw':clean_text(row.get('事業終了（予定）年度')),'priorBudgetFiscalYear':prior,'priorBudgetYen':yen_from_thousand(row.get(f'{prior}年度予算額計'),none_if_blank=True),'priorExecutionYen':yen_from_thousand(row.get(f'{prior}年度執行額'),none_if_blank=True),'currentInitialFiscalYear':year,'currentInitialYen':yen_from_thousand(row.get(f'{year}年度当初予算額'),none_if_blank=True),'nextRequestFiscalYear':nexty,'nextRequestYen':yen_from_thousand(row.get(f'{nexty}年度要求額'),none_if_blank=True),'requestDifferenceYen':yen_from_thousand(row.get('差引き（要求-当初）'),none_if_blank=True),'externalExpertFinding':clean_text(row.get('外部有識者の所見')),'reflectionAmountYen':yen_from_thousand(row.get('反映額'),none_if_blank=True),'improvementReflection':clean_text(row.get('改善点・反映状況')),'externalReviewTarget':clean_text(row.get(f'{year}年度外部有識者点検対象')),'externalReviewReason':clean_text(row.get(f'{year}年度外部有識者点検対象とした理由')),'latestExternalReviewYearRaw':clean_text(row.get('直近の外部有識者点検実施年度'))})
            else:
                nexty=year+1;rec.update({'projectCategory':'new_request','nextRequestFiscalYear':nexty,'nextRequestYen':yen_from_thousand(row.get(f'{nexty}年度要求額'),none_if_blank=True)})
            known=set(rec.keys())
            # Track all sheet source columns not already semantically consumed.
            consumed={'政策','施策','予算事業ID','事業名','事業所管課室','会計区分','事業URL','行政事業レビュー推進チームの所見'}
            if form=='form1': consumed|={'事業開始年度','事業終了（予定）年度',f'{year-1}年度予算額計',f'{year-1}年度執行額',f'{year}年度当初予算額',f'{year+1}年度要求額','差引き（要求-当初）','外部有識者の所見','反映額','改善点・反映状況',f'{year}年度外部有識者点検対象',f'{year}年度外部有識者点検対象とした理由','直近の外部有識者点検実施年度'}
            else: consumed|={f'{year+1}年度要求額'}
            rec['extraFields']=_extra_fields(row,consumed);rec['recordId']=stable_id(relpath(path,raw_root),row_number,prefix='rssheet_');out.append(rec)
    return out,{'sourceYear':year,'available':True,'files':files,'ignoredFiles':ignored,'rowCount':len(out),'formCounts':dict(Counter(r['sheetForm'] for r in out)),'officialProjectUrlCount':sum(bool(r.get('officialProjectUrl')) for r in out)}


def _merge_projects(download_rows:list[dict[str,Any]],sheet_rows:list[dict[str,Any]],year:int) -> tuple[list[dict[str,Any]],list[dict[str,Any]]]:
    by:dict[str,dict[str,Any]]={};conflicts=[]
    for r in download_rows:
        pid=r['projectId']
        if not pid: continue
        p={k:v for k,v in r.items() if k not in {'recordType','recordId','source'}}
        p.update({'recordType':'rs_project','recordId':stable_id(year,pid,prefix='rsproject_'),'projectIdRawVariants':[r.get('projectIdRaw','')],'sources':[r['source']],'officialProjectUrl':'','sourceKinds':['download-csv:1-2']})
        by[pid]=p
    supplement_fields=['projectName','startYear','endYear','accountClass','officialProjectUrl']
    for s in sheet_rows:
        pid=s.get('projectId','')
        if not pid: continue
        if pid not in by:
            by[pid]={'schemaVersion':SCHEMA_VERSION,'sourceSystem':'rs','sourceYear':year,'reviewYear':year,'recordType':'rs_project','recordId':stable_id(year,pid,prefix='rsproject_'),'projectId':pid,'projectIdRaw':s.get('projectIdRaw',''),'projectIdRawVariants':[s.get('projectIdRaw','')],'projectName':s.get('projectName',''),'policyMinistry':'','ministry':s.get('ministryFromFile',''),'bureau':'','department':'','division':s.get('responsibleOffice',''),'office':'','team':'','unit':'','purpose':'','currentIssues':'','overview':'','overviewUrl':'','projectCategory':s.get('projectCategory',''),'startYear':s.get('startYear'),'startYearUnknown':None,'endYear':s.get('endYear'),'endYearRaw':s.get('endYearRaw',''),'noPlannedEnd':None,'majorExpense':'','note':'','implementationMethods':{},'legacyProjectNumber':'','displayOrderRaw':'','extraFields':{},'officialProjectUrl':s.get('officialProjectUrl',''),'accountClass':s.get('accountClass',''),'sources':[s['source']],'sourceKinds':[f"sheets:{s['sheetForm']}"]}
        else:
            p=by[pid];p['sources'].append(s['source']);p['sourceKinds'].append(f"sheets:{s['sheetForm']}");raw=s.get('projectIdRaw','')
            if raw and raw not in p['projectIdRawVariants']:p['projectIdRawVariants'].append(raw)
            for field in supplement_fields:
                sv=s.get(field)
                if sv in (None,''): continue
                pv=p.get(field)
                if pv in (None,''):
                    p[field]=sv
                elif normalize_text(str(pv))!=normalize_text(str(sv)):
                    conflicts.append({'sourceYear':year,'projectId':pid,'field':field,'downloadValue':pv,'sheetValue':sv,'sheetRecordId':s['recordId']})
    return sorted(by.values(),key=lambda x:x['projectId']),conflicts


def normalize_rs(raw_root: Path, output_root: Path, years: set[int] | None = None) -> dict[str, Any]:
    """Normalize every available RS source year without retaining full datasets in memory.

    Each source file is intentionally handled and released before moving to the next
    one. The 3-1/2-1 datasets are large enough that keeping prior result arrays alive
    can otherwise turn a linear transform into a memory-pressure problem.
    """
    import gc

    all_manifest: dict[str, Any] = {'schemaVersion': SCHEMA_VERSION, 'sourceYears': {}}
    for year in discover_rs_years(raw_root, years):
        year_dir = raw_root / 'rssystem.go.jp' / 'download-csv' / str(year)
        out_dir = output_root / 'normalized' / 'rs' / f'review-{year}'
        inventory: list[dict[str, Any]] = []
        counts: dict[str, int] = {}

        sheet_rows, sheet_manifest = normalize_review_sheets(raw_root, year)
        write_jsonl(out_dir / 'review-sheets.jsonl', sheet_rows)
        counts['review-sheets'] = len(sheet_rows)

        def get(code: str) -> Path | None:
            return _find_zip(year_dir, code, year)

        p = get('1-1')
        if p:
            rows, inv = normalize_organizations(raw_root, p, year)
            inventory.append(inv)
        else:
            rows = []
        write_jsonl(out_dir / 'organizations.jsonl', rows)
        counts['organizations'] = len(rows)
        del rows
        gc.collect()

        p = get('1-2')
        if p:
            project_source_rows, inv = normalize_project_rows(raw_root, p, year)
            inventory.append(inv)
        else:
            project_source_rows = []
        projects, project_conflicts = _merge_projects(project_source_rows, sheet_rows, year)
        write_jsonl(out_dir / 'projects.jsonl', projects)
        counts['projects'] = len(projects)
        write_jsonl(out_dir / 'project-source-rows.jsonl', project_source_rows)
        counts['project-source-rows'] = len(project_source_rows)
        write_jsonl(out_dir / 'project-sheet-conflicts.jsonl', project_conflicts)
        counts['project-sheet-conflicts'] = len(project_conflicts)
        project_conflict_count = len(project_conflicts)
        del projects, project_source_rows, project_conflicts, sheet_rows
        gc.collect()

        for code, func, filename in [
            ('1-3', normalize_policies_laws, 'policies-laws.jsonl'),
            ('1-4', normalize_subsidy_rules, 'subsidy-rules.jsonl'),
            ('1-5', normalize_project_relations, 'project-relations.jsonl'),
        ]:
            p = get(code)
            if p:
                rows, inv = func(raw_root, p, year)
                inventory.append(inv)
            else:
                rows = []
            write_jsonl(out_dir / filename, rows)
            counts[filename[:-6]] = len(rows)
            del rows
            gc.collect()

        p = get('2-1')
        if p:
            sums, events, inv = normalize_budget_summary(raw_root, p, year)
            inventory.append(inv)
        else:
            sums, events = [], []
        write_jsonl(out_dir / 'budget-summaries.jsonl', sums)
        write_jsonl(out_dir / 'budget-events.jsonl', events)
        counts['budget-summaries'] = len(sums)
        counts['budget-events'] = len(events)
        del sums, events
        gc.collect()

        p = get('2-2')
        if p:
            items, inv = normalize_budget_items(raw_root, p, year)
            inventory.append(inv)
        else:
            items = []
        write_jsonl(out_dir / 'budget-items.jsonl', items)
        counts['budget-items'] = len(items)
        del items
        gc.collect()

        p = get('3-1')
        if p:
            nodes, obs, inv = normalize_logic_model(raw_root, p, year)
            inventory.append(inv)
        else:
            nodes, obs = [], []
        write_jsonl(out_dir / 'logic-model-nodes.jsonl', nodes)
        write_jsonl(out_dir / 'logic-model-observations.jsonl', obs)
        counts['logic-model-nodes'] = len(nodes)
        counts['logic-model-observations'] = len(obs)
        del nodes, obs
        gc.collect()

        p = get('3-2')
        if p:
            lrels, inv = normalize_logic_relations(raw_root, p, year)
            inventory.append(inv)
        else:
            lrels = []
        write_jsonl(out_dir / 'logic-model-relations.jsonl', lrels)
        counts['logic-model-relations'] = len(lrels)
        del lrels
        gc.collect()

        p = get('4-1')
        if p:
            evals, inv = normalize_evaluations(raw_root, p, year)
            inventory.append(inv)
        else:
            evals = []
        write_jsonl(out_dir / 'evaluations.jsonl', evals)
        counts['evaluations'] = len(evals)
        del evals
        gc.collect()

        p = get('5-1')
        if p:
            blocks, recips, contracts, inv = normalize_spending(raw_root, p, year)
            inventory.append(inv)
        else:
            blocks, recips, contracts = [], [], []
        write_jsonl(out_dir / 'spending-blocks.jsonl', blocks)
        write_jsonl(out_dir / 'recipients.jsonl', recips)
        write_jsonl(out_dir / 'contracts.jsonl', contracts)
        counts['spending-blocks'] = len(blocks)
        counts['recipients'] = len(recips)
        counts['contracts'] = len(contracts)
        # Compatibility view only; blocks/recipients/contracts are canonical.
        compat = [
            {
                'schemaVersion': SCHEMA_VERSION,
                'recordType': 'rs_expenditure_compat',
                'projectId': c['projectId'],
                'projectIdRaw': c['projectIdRaw'],
                'sourceYear': year,
                'blockId': c['blockId'],
                'recipientId': c.get('recipientId'),
                'recipientName': c.get('recipientNameRaw', ''),
                'corporateNumber': c.get('corporateNumberRaw', ''),
                'amount': c.get('amountYen'),
                'contractId': c['contractId'],
                'source': c['source'],
            }
            for c in contracts
        ]
        write_jsonl(out_dir / 'expenditures.jsonl', compat)
        counts['expenditures'] = len(compat)
        del blocks, recips, contracts, compat
        gc.collect()

        p = get('5-2')
        if p:
            frels, indirect, inv = normalize_funding_relations(raw_root, p, year)
            inventory.append(inv)
        else:
            frels, indirect = [], []
        write_jsonl(out_dir / 'funding-relations.jsonl', frels)
        write_jsonl(out_dir / 'indirect-expenses.jsonl', indirect)
        counts['funding-relations'] = len(frels)
        counts['indirect-expenses'] = len(indirect)
        del frels, indirect
        gc.collect()

        p = get('5-3')
        if p:
            uses, inv = normalize_expense_uses(raw_root, p, year)
            inventory.append(inv)
        else:
            uses = []
        write_jsonl(out_dir / 'expense-uses.jsonl', uses)
        counts['expense-uses'] = len(uses)
        del uses
        gc.collect()

        p = get('5-4')
        if p:
            multi, inv = normalize_multi_year_contracts(raw_root, p, year)
            inventory.append(inv)
        else:
            multi = []
        write_jsonl(out_dir / 'multi-year-contracts.jsonl', multi)
        counts['multi-year-contracts'] = len(multi)
        del multi
        gc.collect()

        p = get('6-1')
        if p:
            notes, inv = normalize_notes(raw_root, p, year)
            inventory.append(inv)
        else:
            notes = []
        write_jsonl(out_dir / 'notes.jsonl', notes)
        counts['notes'] = len(notes)
        del notes
        gc.collect()

        available_codes = [i['datasetCode'] for i in inventory]
        manifest = {
            'schemaVersion': SCHEMA_VERSION,
            'sourceYear': year,
            'reviewYear': year,
            'downloadCsvAvailable': bool(inventory),
            'availableDatasetCodes': available_codes,
            'missingDatasetCodes': [c for c in DATASETS if c not in available_codes],
            'datasetInventory': inventory,
            'reviewSheets': sheet_manifest,
            'recordCounts': dict(sorted(counts.items())),
            'projectSheetConflictCount': project_conflict_count,
        }
        write_json(out_dir / 'manifest.json', manifest)
        all_manifest['sourceYears'][str(year)] = manifest
        gc.collect()

    write_json(output_root / 'normalized' / 'rs' / 'manifest.json', all_manifest)
    return all_manifest
