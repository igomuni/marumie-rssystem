from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import unicodedata
import zipfile
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Iterable, Iterator
from functools import lru_cache

SCHEMA_VERSION = 2


def normalize_text(value: str | None) -> str:
    if not value:
        return ""
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", value)).strip()


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    return unicodedata.normalize("NFC", str(value)).strip()


def canonical_project_id(value: Any) -> str:
    """Canonical RS project identity while preserving raw representation elsewhere.

    Numeric IDs are normalized by removing leading zeroes. Non-numeric IDs are
    retained as NFKC text because silently coercing them to numbers would lose
    identity information.
    """
    raw = clean_text(value)
    if not raw:
        return ""
    n = unicodedata.normalize("NFKC", raw)
    if re.fullmatch(r"[0-9]+", n):
        return n.lstrip("0") or "0"
    return n


def parse_bool(value: Any) -> bool | None:
    s = unicodedata.normalize("NFKC", clean_text(value)).upper()
    if not s:
        return None
    if s in {"TRUE", "1", "YES", "Y", "○", "有", "あり"}:
        return True
    if s in {"FALSE", "0", "NO", "N", "×", "無", "なし"}:
        return False
    return None


def _decimal(value: Any) -> Decimal | None:
    if value is None:
        return None
    s = clean_text(value).replace(",", "")
    if not s or s in {"-", "--", "―", "ー"}:
        return None
    try:
        return Decimal(s)
    except InvalidOperation:
        return None


def parse_int(value: Any, *, none_if_blank: bool = False) -> int | None:
    if value is None:
        return None if none_if_blank else 0
    s = clean_text(value).replace(",", "")
    if not s:
        return None if none_if_blank else 0
    d = _decimal(s)
    if d is None:
        return None if none_if_blank else 0
    try:
        return int(d)
    except (ValueError, OverflowError):
        return None if none_if_blank else 0


def parse_number(value: Any) -> int | float | None:
    """Parse a source numeric cell without collapsing blank to zero."""
    d = _decimal(value)
    if d is None:
        return None
    if d == d.to_integral_value():
        return int(d)
    return float(d)


def yen_from_thousand(value: Any, *, none_if_blank: bool = False) -> int | None:
    d = _decimal(value)
    if d is None:
        return None if none_if_blank else 0
    # Review-sheet currency columns are thousand yen. Decimal preserves values
    # such as 11200.834 -> 11,200,834 yen exactly.
    return int(d * Decimal(1000))


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stable_id(*parts: Any, prefix: str = "") -> str:
    payload = "\x1f".join(normalize_text(str(p)) for p in parts)
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:20]
    return f"{prefix}{digest}"


def read_zip_csv_entries(zip_path: Path) -> list[tuple[str, list[dict[str, str]]]]:
    out: list[tuple[str, list[dict[str, str]]]] = []
    with zipfile.ZipFile(zip_path) as zf:
        for name in sorted(zf.namelist()):
            if not name.lower().endswith(".csv"):
                continue
            raw = zf.read(name)
            try:
                text = raw.decode("utf-8-sig")
            except UnicodeDecodeError:
                text = raw.decode("cp932")
            rows = list(csv.DictReader(io.StringIO(text)))
            out.append((name, rows))
    return out


def read_csv_file(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    raw = path.read_bytes()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("cp932")
    reader = csv.DictReader(io.StringIO(text))
    return list(reader.fieldnames or []), list(reader)


def is_expenditure_headers(headers: Iterable[str]) -> bool:
    return any("主要経費別分類" in h or "使途別分類" in h for h in headers)


def expenditure_zip_entry(zip_path: Path) -> tuple[str, list[dict[str, str]]]:
    for name, rows in read_zip_csv_entries(zip_path):
        if rows and is_expenditure_headers(rows[0].keys()):
            return name, rows
    raise ValueError(f"expenditure CSV not found in {zip_path}")


def find_header(headers: Iterable[str], *needles: str, exclude: tuple[str, ...] = ()) -> str | None:
    for header in headers:
        if all(n in header for n in needles) and not any(x in header for x in exclude):
            return header
    return None


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write("\n")


def write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with path.open("w", encoding="utf-8", newline="\n") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
            f.write("\n")
            count += 1
    return count


def read_jsonl(path: Path) -> Iterator[dict[str, Any]]:
    if not path.exists():
        return iter(())

    def _iter() -> Iterator[dict[str, Any]]:
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    yield json.loads(line)

    return _iter()


@lru_cache(maxsize=512)
def _relpath_cached(path_s: str, root_s: str) -> str:
    # Source paths repeat for every row. Resolving them per record dominated
    # runtime on 3-1 (128k rows), so cache the filesystem normalization.
    return Path(path_s).resolve().relative_to(Path(root_s).resolve()).as_posix()


def relpath(path: Path, root: Path) -> str:
    return _relpath_cached(str(path), str(root))


def source_ref(
    raw_root: Path,
    source_path: Path,
    entry: str | None,
    row_number: int | None,
    *,
    dataset: str | None = None,
    year: int | None = None,
    source_url: str | None = None,
) -> dict[str, Any]:
    ref: dict[str, Any] = {
        "domain": "rssystem.go.jp" if "rssystem.go.jp" in source_path.as_posix() else "mof.go.jp",
        "path": relpath(source_path, raw_root),
        "file": source_path.name,
    }
    if dataset:
        ref["dataset"] = dataset
    if year is not None:
        ref["year"] = year
    if entry:
        ref["zipEntry"] = entry
    if row_number is not None:
        ref["rowNumber"] = row_number
    if source_url:
        ref["sourceUrl"] = source_url
    return ref


def sorted_dict_rows(rows: Iterable[dict[str, Any]], *keys: str) -> list[dict[str, Any]]:
    return sorted(rows, key=lambda r: tuple(str(r.get(k, "")) for k in keys))
