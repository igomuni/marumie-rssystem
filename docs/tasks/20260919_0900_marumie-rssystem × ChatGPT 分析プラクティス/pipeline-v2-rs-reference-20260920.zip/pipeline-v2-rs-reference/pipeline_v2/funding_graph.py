from __future__ import annotations

from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Iterable

from .common import SCHEMA_VERSION, normalize_text, read_jsonl, stable_id, write_jsonl, write_json


def _tarjan_scc(node_ids: list[str], adjacency: dict[str, set[str]]) -> list[list[str]]:
    index = 0
    stack: list[str] = []
    on_stack: set[str] = set()
    indices: dict[str, int] = {}
    low: dict[str, int] = {}
    out: list[list[str]] = []

    def visit(v: str) -> None:
        nonlocal index
        indices[v] = index
        low[v] = index
        index += 1
        stack.append(v)
        on_stack.add(v)
        for w in adjacency.get(v, set()):
            if w not in indices:
                visit(w)
                low[v] = min(low[v], low[w])
            elif w in on_stack:
                low[v] = min(low[v], indices[w])
        if low[v] == indices[v]:
            component: list[str] = []
            while True:
                w = stack.pop()
                on_stack.remove(w)
                component.append(w)
                if w == v:
                    break
            out.append(component)

    for node in node_ids:
        if node not in indices:
            visit(node)
    return out


def _weak_components(node_ids: list[str], edges: Iterable[tuple[str, str]]) -> list[list[str]]:
    adj: dict[str, set[str]] = {n: set() for n in node_ids}
    for a, b in edges:
        if a in adj and b in adj:
            adj[a].add(b)
            adj[b].add(a)
    seen: set[str] = set()
    comps: list[list[str]] = []
    for start in node_ids:
        if start in seen:
            continue
        seen.add(start)
        q = [start]
        comp: list[str] = []
        while q:
            n = q.pop()
            comp.append(n)
            for nxt in adj[n]:
                if nxt not in seen:
                    seen.add(nxt)
                    q.append(nxt)
        comps.append(sorted(comp))
    return comps


def _block_node(block: dict[str, Any]) -> dict[str, Any]:
    return {
        'nodeId': block['nodeId'],
        'nodeType': 'spending_block',
        'blockId': block.get('blockId', ''),
        'name': block.get('blockName', ''),
        'nameVariants': block.get('blockNames', []),
        'roles': block.get('roles', []),
        'recipientCountValues': block.get('recipientCountValues', []),
        'totalAmountValuesYen': block.get('totalAmountValuesYen', []),
        'summaryRowCount': block.get('summaryRowCount', 0),
        'evidenceRowIds': block.get('evidenceRowIds', []),
    }


def build_funding_graphs_for_year(output_root: Path, review_year: int) -> dict[str, Any]:
    """Build source-faithful RS funding graphs from normalized 5-1 and 5-2.

    The derived graph intentionally does *not* force tree/DAG/single-root semantics,
    does not infer missing ministry edges, and never invents an edge amount.
    """
    norm_dir = output_root / 'normalized' / 'rs' / f'review-{review_year}'
    out_dir = output_root / 'derived' / 'rs' / f'review-{review_year}'

    blocks_by_project: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in read_jsonl(norm_dir / 'spending-blocks.jsonl'):
        blocks_by_project[row.get('projectId', '')].append(row)

    rels_by_project: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in read_jsonl(norm_dir / 'funding-relations.jsonl'):
        rels_by_project[row.get('projectId', '')].append(row)

    indirect_by_project: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in read_jsonl(norm_dir / 'indirect-expenses.jsonl'):
        indirect_by_project[row.get('projectId', '')].append(row)

    project_meta = {r.get('projectId', ''): r for r in read_jsonl(norm_dir / 'projects.jsonl')}
    project_ids = sorted(set(blocks_by_project) | set(rels_by_project) | set(indirect_by_project))

    graphs: list[dict[str, Any]] = []
    totals = {
        'projectCount': 0,
        'blockNodeCount': 0,
        'responsibleOrganizationNodeCount': 0,
        'relationEvidenceCount': 0,
        'semanticEdgeCount': 0,
        'indirectExpenseCount': 0,
        'projectsWithCycles': 0,
        'projectsWithMultipleWeakComponents': 0,
        'projectsWithOrphanBlocks': 0,
        'projectsWithDuplicateRelationPairs': 0,
        'unresolvedRelationEvidenceCount': 0,
    }

    for pid in project_ids:
        blocks = sorted(blocks_by_project.get(pid, []), key=lambda b: b.get('blockId', ''))
        rels = rels_by_project.get(pid, [])
        indirect = indirect_by_project.get(pid, [])
        meta = project_meta.get(pid, {})

        nodes = [_block_node(b) for b in blocks]
        block_node_by_id = {b.get('blockId', ''): b.get('nodeId', '') for b in blocks if b.get('blockId')}
        responsible_needed = any(r.get('fromResponsibleOrganization') is True and not r.get('sourceBlockId') for r in rels)
        responsible_node_id = f'project:{pid}:responsible' if responsible_needed else None
        if responsible_needed:
            responsible_name = meta.get('ministry') or meta.get('policyMinistry') or '担当組織'
            nodes.append({
                'nodeId': responsible_node_id,
                'nodeType': 'responsible_organization',
                'blockId': None,
                'name': responsible_name,
                'nameVariants': [responsible_name] if responsible_name else [],
                'roles': [],
                'synthetic': True,
                'syntheticReason': '5-2 担当組織からの支出=TRUE and sourceBlockId is blank',
            })

        pair_evidence: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
        unresolved_relation_ids: list[str] = []
        unresolved_details: list[dict[str, Any]] = []
        for rel in rels:
            sbid = rel.get('sourceBlockId')
            tbid = rel.get('targetBlockId')
            if sbid:
                source_node = block_node_by_id.get(sbid)
                source_resolution = '5-1-block'
            elif rel.get('fromResponsibleOrganization') is True:
                source_node = responsible_node_id
                source_resolution = 'responsible-organization'
            else:
                source_node = None
                source_resolution = 'unresolved'
            target_node = block_node_by_id.get(tbid or '') if tbid else None
            if not source_node or not target_node:
                unresolved_relation_ids.append(rel.get('relationId', ''))
                unresolved_details.append({
                    'relationId': rel.get('relationId', ''),
                    'sourceBlockId': sbid,
                    'targetBlockId': tbid,
                    'sourceResolution': source_resolution,
                    'targetResolution': '5-1-block' if target_node else 'unresolved',
                })
                continue
            pair_evidence[(source_node, target_node)].append(rel)

        semantic_edges: list[dict[str, Any]] = []
        duplicate_pairs: list[dict[str, Any]] = []
        for (source_node, target_node), evidence in sorted(pair_evidence.items()):
            notes = []
            source_names = []
            target_names = []
            from_org_values: list[bool | None] = []
            for r in evidence:
                for value, arr in [
                    (r.get('note', ''), notes),
                    (r.get('sourceBlockName', ''), source_names),
                    (r.get('targetBlockName', ''), target_names),
                ]:
                    if value and value not in arr:
                        arr.append(value)
                if r.get('fromResponsibleOrganization') not in from_org_values:
                    from_org_values.append(r.get('fromResponsibleOrganization'))
            edge = {
                'edgeId': stable_id(review_year, pid, source_node, target_node, prefix='rsedge_'),
                'sourceNodeId': source_node,
                'targetNodeId': target_node,
                'amountYen': None,
                'amountStatus': 'not_provided_by_5-2',
                'evidenceRelationIds': [r.get('relationId', '') for r in evidence],
                'evidenceCount': len(evidence),
                'noteVariants': notes,
                'sourceNameVariants': source_names,
                'targetNameVariants': target_names,
                'fromResponsibleOrganizationValues': from_org_values,
            }
            semantic_edges.append(edge)
            if len(evidence) > 1:
                duplicate_pairs.append({
                    'sourceNodeId': source_node,
                    'targetNodeId': target_node,
                    'evidenceCount': len(evidence),
                    'evidenceRelationIds': edge['evidenceRelationIds'],
                    'noteVariants': notes,
                })

        node_ids = [n['nodeId'] for n in nodes]
        edge_pairs = [(e['sourceNodeId'], e['targetNodeId']) for e in semantic_edges]
        indegree = {n: 0 for n in node_ids}
        outdegree = {n: 0 for n in node_ids}
        adjacency: dict[str, set[str]] = defaultdict(set)
        for a, b in edge_pairs:
            if a in outdegree and b in indegree:
                outdegree[a] += 1
                indegree[b] += 1
                adjacency[a].add(b)

        scc = _tarjan_scc(node_ids, adjacency)
        cyclic_components = []
        for comp in scc:
            if len(comp) > 1:
                cyclic_components.append(sorted(comp))
            elif comp and comp[0] in adjacency.get(comp[0], set()):
                cyclic_components.append(comp)
        weak_components = _weak_components(node_ids, edge_pairs)

        block_node_ids = set(block_node_by_id.values())
        orphan_blocks = sorted(
            b.get('blockId', '') for b in blocks
            if b.get('nodeId') in block_node_ids
            and indegree.get(b.get('nodeId', ''), 0) == 0
            and outdegree.get(b.get('nodeId', ''), 0) == 0
        )
        root_nodes = sorted(n for n in node_ids if indegree.get(n, 0) == 0)
        external_root_blocks = sorted(
            b.get('blockId', '') for b in blocks
            if indegree.get(b.get('nodeId', ''), 0) == 0
            and outdegree.get(b.get('nodeId', ''), 0) > 0
        )

        by_name: dict[str, list[str]] = defaultdict(list)
        for b in blocks:
            nm = normalize_text(b.get('blockName', ''))
            if nm:
                by_name[nm].append(b.get('blockId', ''))
        same_name_multiple = [
            {'normalizedName': name, 'blockIds': sorted(set(ids))}
            for name, ids in sorted(by_name.items())
            if len(set(ids)) > 1
        ]

        graph = {
            'schemaVersion': SCHEMA_VERSION,
            'recordType': 'rs_funding_graph',
            'reviewYear': review_year,
            'sourceYear': review_year,
            'projectId': pid,
            'projectName': meta.get('projectName', ''),
            'ministry': meta.get('ministry', ''),
            'nodes': nodes,
            'semanticEdges': semantic_edges,
            'unresolvedRelationIds': unresolved_relation_ids,
            'unresolvedRelationDetails': unresolved_details,
            'metrics': {
                'blockCount': len(blocks),
                'nodeCount': len(nodes),
                'relationEvidenceCount': len(rels),
                'semanticEdgeCount': len(semantic_edges),
                'indirectExpenseCount': len(indirect),
                'responsibleOrganizationNodeId': responsible_node_id,
                'hasResponsibleOrganizationRoot': bool(responsible_node_id),
                'rootNodeIds': root_nodes,
                'externalRootBlockIds': external_root_blocks,
                'orphanBlockIds': orphan_blocks,
                'duplicateRelationPairCount': len(duplicate_pairs),
                'duplicateRelationEvidenceExtraCount': sum(max(0, d['evidenceCount'] - 1) for d in duplicate_pairs),
                'hasCycle': bool(cyclic_components),
                'cyclicComponents': cyclic_components,
                'weakComponentCount': len(weak_components),
                'weakComponentSizes': sorted((len(c) for c in weak_components), reverse=True),
                'maxOutDegree': max(outdegree.values(), default=0),
                'maxInDegree': max(indegree.values(), default=0),
                'sameNameMultipleBlocks': same_name_multiple,
                'unresolvedRelationEvidenceCount': len(unresolved_relation_ids),
            },
            'duplicateRelationPairs': duplicate_pairs,
        }
        graphs.append(graph)

        totals['projectCount'] += 1
        totals['blockNodeCount'] += len(blocks)
        totals['responsibleOrganizationNodeCount'] += int(responsible_needed)
        totals['relationEvidenceCount'] += len(rels)
        totals['semanticEdgeCount'] += len(semantic_edges)
        totals['indirectExpenseCount'] += len(indirect)
        totals['projectsWithCycles'] += int(bool(cyclic_components))
        totals['projectsWithMultipleWeakComponents'] += int(len(weak_components) > 1)
        totals['projectsWithOrphanBlocks'] += int(bool(orphan_blocks))
        totals['projectsWithDuplicateRelationPairs'] += int(bool(duplicate_pairs))
        totals['unresolvedRelationEvidenceCount'] += len(unresolved_relation_ids)

    write_jsonl(out_dir / 'funding-graphs.jsonl', graphs)
    summary = {
        'schemaVersion': SCHEMA_VERSION,
        'reviewYear': review_year,
        **totals,
    }
    write_json(out_dir / 'funding-graph-summary.json', summary)
    return summary


def build_funding_graphs(output_root: Path, review_years: Iterable[int]) -> dict[str, Any]:
    result: dict[str, Any] = {'schemaVersion': SCHEMA_VERSION, 'reviewYears': {}}
    for year in review_years:
        norm = output_root / 'normalized' / 'rs' / f'review-{year}'
        if not norm.exists():
            continue
        result['reviewYears'][str(year)] = build_funding_graphs_for_year(output_root, year)
    write_json(output_root / 'derived' / 'rs' / 'funding-graph-manifest.json', result)
    return result
