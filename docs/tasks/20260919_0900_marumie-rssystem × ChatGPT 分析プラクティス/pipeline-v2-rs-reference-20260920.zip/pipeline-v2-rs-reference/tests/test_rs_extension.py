import unittest
from collections import defaultdict

from pipeline_v2.common import canonical_project_id, parse_bool, parse_number
from pipeline_v2.funding_graph import _tarjan_scc, _weak_components


class CommonSemanticsTest(unittest.TestCase):
    def test_project_id_canonicalization_preserves_identity(self):
        self.assertEqual(canonical_project_id('000004'), '4')
        self.assertEqual(canonical_project_id('4'), '4')
        self.assertEqual(canonical_project_id('ABC-01'), 'ABC-01')

    def test_blank_and_zero_are_different(self):
        self.assertIsNone(parse_number(''))
        self.assertEqual(parse_number('0'), 0)
        self.assertEqual(parse_number('0.0'), 0)

    def test_bool_parser(self):
        self.assertIs(parse_bool('TRUE'), True)
        self.assertIs(parse_bool('FALSE'), False)
        self.assertIsNone(parse_bool(''))


class FundingGraphAlgorithmsTest(unittest.TestCase):
    def test_cycle_is_allowed_and_detectable(self):
        nodes = ['A','B','C']
        adj = defaultdict(set, {'A': {'B'}, 'B': {'A','C'}})
        comps = _tarjan_scc(nodes, adj)
        self.assertIn({'A','B'}, [set(c) for c in comps])

    def test_disconnected_components_are_allowed(self):
        comps = _weak_components(['A','B','C','D'], [('A','B'),('C','D')])
        self.assertEqual(sorted(len(c) for c in comps), [2,2])

    def test_isolated_blocks_are_components(self):
        comps = _weak_components(['A','B','C'], [])
        self.assertEqual(len(comps), 3)


if __name__ == '__main__':
    unittest.main()
