# Pipeline V2 RS拡張 参照実装 検証レポート

## 結論

- Acceptance assertions: **17/17 PASS**
- Overall: **PASS**

## 2025 download-csv 15系統

| code | dataset | rows | cols |
|---|---|---:|---:|
| 1-1 | 基本情報_組織情報 | 8,540 | 22 |
| 1-2 | 基本情報_事業概要等 | 6,061 | 32 |
| 1-3 | 基本情報_政策・施策、法令等 | 15,821 | 28 |
| 1-4 | 基本情報_補助率等 | 6,080 | 18 |
| 1-5 | 基本情報_関連事業 | 6,302 | 17 |
| 2-1 | 予算・執行_サマリ | 47,100 | 44 |
| 2-2 | 予算・執行_予算種別・歳出予算項目 | 70,915 | 26 |
| 3-1 | 効果発現経路_目標・実績 | 128,516 | 82 |
| 3-2 | 効果発現経路_目標のつながり | 31,726 | 25 |
| 4-1 | 点検・評価 | 5,831 | 37 |
| 5-1 | 支出先_支出情報 | 193,912 | 32 |
| 5-2 | 支出先_支出ブロックのつながり | 23,381 | 22 |
| 5-3 | 支出先_費目・使途 | 34,307 | 20 |
| 5-4 | 支出先_国庫債務負担行為等による契約 | 9,716 | 27 |
| 6-1 | その他備考 | 5,794 | 14 |

## 5-1 / 5-2 / Funding Graph

- 5-1 block: **20,497**
- 5-2参照blockの5-1欠落: **0**
- 5-1/5-2 block名不一致: **0**
- orphan block: **125 / 60事業**
- Funding graph projects: **5,591**
- cycleあり: **1事業**
- duplicate source-target relationあり: **107事業**
- indirect expense rows: **2,432**

## PID:4 semantic regression

- `-509,690,849,950` は `adjustment` として **2件**確認（project total / account evidence）
- PID:4 FY2024 の `reserve` event: **0件**
- `予備費等` を Normalized で reserve と断定しない条件を満たす。

## Stress fixtures

| PID | blocks | rel evidence | cycle | weak components | max out | max in | orphan | duplicate pairs | indirect |
|---:|---:|---:|:---:|---:|---:|---:|---:|---:|---:|
| 1 | 8 | 8 | no | 1 | 8 | 1 | 0 | 0 | 2 |
| 4 | 2 | 2 | no | 1 | 2 | 1 | 0 | 0 | 0 |
| 12 | 9 | 9 | no | 1 | 5 | 1 | 0 | 0 | 0 |
| 1409 | 4 | 5 | yes | 1 | 2 | 2 | 0 | 0 | 0 |
| 2776 | 2 | 1 | no | 1 | 1 | 1 | 0 | 0 | 0 |
| 142 | 33 | 40 | no | 1 | 8 | 2 | 0 | 0 | 0 |
| 500 | 10 | 18 | no | 1 | 9 | 9 | 0 | 0 | 0 |
| 1406 | 5 | 5 | no | 1 | 1 | 3 | 0 | 0 | 0 |
| 3339 | 30 | 0 | no | 30 | 0 | 0 | 30 | 0 | 0 |
| 333 | 6 | 5 | no | 2 | 2 | 1 | 0 | 0 | 0 |
| 18 | 12 | 12 | no | 1 | 4 | 1 | 0 | 0 | 0 |
| 747 | 28 | 52 | no | 1 | 9 | 1 | 0 | 21 | 1 |
| 1082 | 55 | 55 | no | 1 | 55 | 1 | 0 | 0 | 0 |
| 4162 | 10 | 10 | no | 1 | 5 | 1 | 0 | 0 | 12 |
| 1675 | 8 | 8 | no | 1 | 4 | 3 | 0 | 0 | 0 |

## 2026 sheets-only normalization

- form1/2 normalized rows: **2,820**
- official project URL: **2,820**
- form2 new-request rows: **213**
- form2 URLあり: **213**
- 2026 download-csvが無くても sheets だけで normalize できることを確認。

## Assertions

- [x] `all15CsvAvailable2025`
- [x] `canonical000004Equals4`
- [x] `blankPreservedAsNull`
- [x] `explicitZeroPreserved`
- [x] `pid4AdjustmentNeutral`
- [x] `no5_2ReferencesMissing5_1Block`
- [x] `noBlockNameMismatch5_1vs5_2`
- [x] `pid1409HasCycle`
- [x] `pid2776HasNoResponsibleRoot`
- [x] `pid333Disconnected`
- [x] `pid3339Has30Orphans`
- [x] `pid747DuplicateRelationsPreserved`
- [x] `pid1082HighFanout`
- [x] `pid4162IndirectExpenses`
- [x] `pid1409DuplicateBlockSummary`
- [x] `sheets2026HasOfficialUrls`
- [x] `sheets2026HasNewRequests`

## 注意

- Funding graph の `weakComponentCount` は孤立blockも1 componentとして数える。PID:3339は30孤立blockなので30 components。
- 5-2 edgeに金額は付与していない。金額は5-1/5-3等の別証拠と混同しない。
- 2026は手元アーカイブ上 `sheets` のみで、download-csv 15系統は存在しない。
